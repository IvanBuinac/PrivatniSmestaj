#
# TABLE STRUCTURE FOR: admin_poruke
#

DROP TABLE IF EXISTS admin_poruke;

CREATE TABLE `admin_poruke` (
  `admin_poruke` int(11) NOT NULL AUTO_INCREMENT,
  `poruka` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_poruke`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: cenausezoni
#

DROP TABLE IF EXISTS cenausezoni;

CREATE TABLE `cenausezoni` (
  `cenausezoni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cenausezoni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (1, 'Minimalna cena po osobi');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (2, 'Predsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (3, 'U sezoni');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (4, 'Postsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (5, 'Van sezone');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3f3a115c7277cb5db4d27f3883d25cce', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36', 1459365985, 'a:6:{s:9:\"user_data\";s:0:\"\";s:3:\"ime\";s:4:\"Ivan\";s:5:\"email\";s:19:\"ivke-92@hotmail.com\";s:11:\"korisnik_id\";s:1:\"1\";s:14:\"privilegija_id\";s:1:\"1\";s:8:\"loggedin\";b:1;}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7215b2451f9d4d04600948310bf09a30', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36', 1459365621, '');


#
# TABLE STRUCTURE FOR: doba
#

DROP TABLE IF EXISTS doba;

CREATE TABLE `doba` (
  `doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slika_obojena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slika_crno_bela` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (1, 'Zima', 'zima.png', 'zima_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (2, 'Leto', 'leto.png', 'leto_iskljuceno.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (3, 'Jesen', 'jesen.png', 'jesen_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (4, 'Prolece', 'prolece.png', 'prolece_iskljuceno.png');


#
# TABLE STRUCTURE FOR: drzava
#

DROP TABLE IF EXISTS drzava;

CREATE TABLE `drzava` (
  `drzava_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`drzava_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (1, 'Srbija', 'srbija', '44.03232064275084', '20.8245849609375', 7, 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (2, 'Crna Gora', 'crna-gora', '42.819580715795915', '19.16839599609375', 8, 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (5, 'Hrvatska', 'hrvatska', '45.39844997630408', '15.99609375', 7, 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (6, 'Grčka', 'grcka', '39.8465036024177', '22.247314453125', 8, 1);


#
# TABLE STRUCTURE FOR: grad
#

DROP TABLE IF EXISTS grad;

CREATE TABLE `grad` (
  `grad_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `drzava_id` int(11) NOT NULL,
  PRIMARY KEY (`grad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (1, 'Beograd', 'beograd', '44.79085081250334', '20.457916259765625', 12, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (2, 'Igalo', 'igalo', '42.45541269782037', '18.506770133972168', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (4, 'Herceg Novi', 'herceg-novi', '42.45230964072516', '18.536295890808105', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (5, 'Kopaonik', 'kopaonik', '43.28542202482845', '20.807676315307617', 15, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (10, 'Budva', 'budva', '42.28594498725423', '18.84507179260254', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (11, 'Podgorica', 'podgorica', '42.431312471126', '19.25731658935547', 13, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (12, 'Zagreb', 'zagreb', '45.805828539928356', '15.975837707519531', 12, 1, 5);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (13, 'Atina', 'atina', '37.96260604160774', '23.729782104492188', 11, 1, 6);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (14, 'Halkidiki', 'halkidiki', '40.455307212131494', '23.42010498046875', 9, 1, 6);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (15, 'Baošići', 'baosici', '42.44334790872497', '18.624916076660156', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (17, 'Bar', 'bar', '42.09083439530846', '19.091835021972656', 13, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (18, 'Djenovići', 'djenovici', '42.4359368863858', '18.608479499816895', 15, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (19, 'Zelenika', 'zelenika', '42.45230964072516', '18.577194213867188', 16, 1, 2);


#
# TABLE STRUCTURE FOR: iznajmljujese
#

DROP TABLE IF EXISTS iznajmljujese;

CREATE TABLE `iznajmljujese` (
  `iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (1, 'sobe');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (2, 'studiji');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (3, 'apartmani');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (4, 'stanovi');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (5, 'ceo objekat');


#
# TABLE STRUCTURE FOR: kalendar_popunjenosti
#

DROP TABLE IF EXISTS kalendar_popunjenosti;

CREATE TABLE `kalendar_popunjenosti` (
  `kalendar_popunjenosti_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `ime_prezime` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smestajna_jed_id` int(11) NOT NULL,
  PRIMARY KEY (`kalendar_popunjenosti_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (1, '2016-03-11', 'pera peric', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (4, '2016-03-14', 'pera peric', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (5, '2016-03-15', 'pera peric', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (6, '2016-03-16', 'pera peric', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (7, '2016-03-17', 'pera peric', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (8, '2016-03-18', 'pera peric', 2);


#
# TABLE STRUCTURE FOR: kapara
#

DROP TABLE IF EXISTS kapara;

CREATE TABLE `kapara` (
  `kapara_id` int(11) NOT NULL AUTO_INCREMENT,
  `vrednost` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kapara_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (1, '5');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (2, '10');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (3, '15');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (4, '20');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (5, '25');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (6, '30');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (7, '35');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (8, '40');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (9, '45');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (10, '50');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (11, '55');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (12, '60');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (13, '65');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (14, '70');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (15, '75');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (16, '80');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (17, '85');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (18, '90');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (19, '95');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (20, '100');


#
# TABLE STRUCTURE FOR: karakteristike
#

DROP TABLE IF EXISTS karakteristike;

CREATE TABLE `karakteristike` (
  `karakteristike_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `chack` int(11) DEFAULT NULL,
  PRIMARY KEY (`karakteristike_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (1, 'Voda 24h', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (2, 'Pogodno za decu', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (3, 'Sef', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (4, 'Bazen', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (5, 'Obezbedjen parking', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (6, 'Garaža', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (7, 'Sobna usluga', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (8, 'Ljubimci dozvoljeni', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (9, 'Kablovska', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (10, 'Pogled na more', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (11, 'Kupatilo', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (12, 'Kuhinja', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (13, 'Balkon', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (14, 'Klima', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (15, 'Velika terasa', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (16, 'Internet', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (17, 'Televizor', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (18, 'Telefon u sobi', NULL);


#
# TABLE STRUCTURE FOR: kategorija
#

DROP TABLE IF EXISTS kategorija;

CREATE TABLE `kategorija` (
  `kategorija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kategorija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (1, '1 Zvezdica');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (2, '2 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (3, '3 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (4, '4 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (5, '5 Zvezdica');


#
# TABLE STRUCTURE FOR: korisnik
#

DROP TABLE IF EXISTS korisnik;

CREATE TABLE `korisnik` (
  `korisnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `privilegija_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `grad` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `max_smestaja` int(11) DEFAULT NULL,
  `max_smestajnih_jed` int(11) DEFAULT NULL,
  `potvrda` int(11) NOT NULL,
  `rand` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  PRIMARY KEY (`korisnik_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (1, 1, 'Ivan', 'Buinac', 'ivke-92@hotmail.com', 'dbbf9cbeb1b31bb85b44d760a970d42048450b316b96f6acabe57206870e0cc6ef554e3c031fbc5a9befed6fe77e53870b84f985ff480373bf66c4f9bdb1945c', '1', 1, 1, 1, 4305, 1459365913, 1459365913);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (2, 2, 'Ivan', 'Buinac', 'ivan.buinac.182.11@ict.edu.rs', 'dbbf9cbeb1b31bb85b44d760a970d42048450b316b96f6acabe57206870e0cc6ef554e3c031fbc5a9befed6fe77e53870b84f985ff480373bf66c4f9bdb1945c', '1', 3, 3, 1, 11821, 0, 0);


#
# TABLE STRUCTURE FOR: korisnik_kontakt
#

DROP TABLE IF EXISTS korisnik_kontakt;

CREATE TABLE `korisnik_kontakt` (
  `korisnik_kontakt_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnik_id` int(11) NOT NULL,
  `telefon` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`korisnik_kontakt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (14, 1, '060/513-79-47');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (15, 2, '060/513-79-47');


#
# TABLE STRUCTURE FOR: legenda
#

DROP TABLE IF EXISTS legenda;

CREATE TABLE `legenda` (
  `legenda_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `slika` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`legenda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (1, 'Svaka soba, apartman', 'yes.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (2, 'Neke sobe, apartmani', 'maybe.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (3, 'Nema', 'no.png');


#
# TABLE STRUCTURE FOR: link
#

DROP TABLE IF EXISTS link;

CREATE TABLE `link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `meni_id` int(11) DEFAULT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tezina` int(11) DEFAULT NULL,
  `roditelj` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (1, 1, 'Početna', '', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (2, 2, 'Linkovi', 'admin/administracija_linkova', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (3, 3, 'Administracija Smestaja', '', 1, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (4, 3, 'Administracija smestaja', 'korisnik/smestaji', 1, 3);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (5, 3, 'Administracija smestajnih jedinica', 'korisnik/smestajne_jedinice', 1, 3);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (6, 3, 'Upiti', 'korisnik/upiti', 1, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (7, 3, 'Svi upiti', 'korisnik/upiti/', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (8, 3, 'Obradjeni', 'korisnik/upiti/obradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (9, 3, 'Neobradjeni', 'korisnik/upiti/neobradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (10, 3, 'Poslati', 'korisnik/upiti/poslati', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (13, 3, 'Moj Profil', 'korisnik/moj_profil', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (14, 2, 'Pretraga', '', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (15, 2, 'Meniji', 'admin/administracija_menija', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (16, 2, 'Dashboard', 'admin/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (17, 2, 'Gradovi', 'admin/administracija_gradova', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (18, 2, 'Drzave', 'admin/administracija_drzava', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (19, 3, 'Dashboard', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (20, 2, 'Doba', 'admin/administracija_doba', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (23, 2, 'Korisnici', 'admin/administracija_korisnika', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (24, 2, 'Smestaji', 'admin/administracija_smestaja', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (26, 2, 'Administracija smestaja', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (27, 2, 'Smestajne jed', 'admin/smestajne_jedinice', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (28, 0, 'Kalendar popunjenosti', 'korisnik/kalendar_popunjenosti', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (29, 0, 'backup_database', 'admin/dashboard/backup_database', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (30, 2, 'Usluge', 'admin/usluge', 0, NULL);


#
# TABLE STRUCTURE FOR: meni
#

DROP TABLE IF EXISTS meni;

CREATE TABLE `meni` (
  `meni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`meni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO meni (`meni_id`, `naziv`) VALUES (1, 'Gornji Meni');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (2, 'Administracija menija');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (3, 'User_meni');


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO migrations (`version`) VALUES (7);


#
# TABLE STRUCTURE FOR: nacinplacanja
#

DROP TABLE IF EXISTS nacinplacanja;

CREATE TABLE `nacinplacanja` (
  `nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slikauboji` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `crnobela` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (1, 'Keš', 'kes.png', 'kes-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (2, 'Bankovni transfer', 'TBanks.png', 'TBanks-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (3, 'Kreditna kartica', 'kartica.png', 'kartica-black.png');


#
# TABLE STRUCTURE FOR: objekat
#

DROP TABLE IF EXISTS objekat;

CREATE TABLE `objekat` (
  `objekat_id` int(11) NOT NULL AUTO_INCREMENT,
  `grad_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `ukupni_kapacitet` int(11) NOT NULL,
  `kordinata_x` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `kordinata_y` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `adresa` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `korisnik_id` int(11) NOT NULL,
  `kategorija_id` int(11) NOT NULL,
  `youtube_link` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kapara_id` int(11) NOT NULL,
  `tip_id` int(11) NOT NULL,
  `premium` int(11) NOT NULL,
  `prioritet` int(11) NOT NULL,
  `posecenost` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  PRIMARY KEY (`objekat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (1, 2, 'Sobe igalo', 'Sobe Igalo', 15, '42.45300625876241', '18.504838943481445', 'http://bbuinac.users.sbb.rs/', 'Dr.Svetozara Zivoinovica', 1, 1, 'https://www.youtube.com/watch?v=pt8VYOfr8To', 6, 3, 1, 15, 800, 1, 1459201999, 1459201999);


#
# TABLE STRUCTURE FOR: objekat_cene
#

DROP TABLE IF EXISTS objekat_cene;

CREATE TABLE `objekat_cene` (
  `objekat_cene_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `sezona_id` int(11) NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_cene_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (31, 1, 2, 1, '3', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (32, 1, 2, 2, '4', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (33, 1, 2, 3, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (34, 1, 2, 4, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (35, 1, 2, 5, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (36, 1, 3, 1, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (37, 1, 3, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (38, 1, 3, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (39, 1, 3, 4, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (40, 1, 3, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (41, 1, 4, 1, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (42, 1, 4, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (43, 1, 4, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (44, 1, 4, 4, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (45, 1, 4, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (46, 1, 5, 1, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (47, 1, 5, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (48, 1, 5, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (49, 1, 5, 4, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (50, 1, 5, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (51, 1, 6, 1, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (52, 1, 6, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (53, 1, 6, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (54, 1, 6, 4, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (55, 1, 6, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (56, 1, 7, 1, '333333333333', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (57, 1, 7, 2, '4', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (58, 1, 7, 3, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (59, 1, 7, 4, '2', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (60, 1, 7, 5, '3', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (61, 1, 8, 1, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (62, 1, 8, 2, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (63, 1, 8, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (64, 1, 8, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (65, 1, 8, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (66, 1, NULL, 1, '5', 3);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (67, 1, NULL, 2, '7', 3);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (68, 1, NULL, 3, '8', 3);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (69, 1, NULL, 4, '7', 3);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (70, 1, NULL, 5, '6', 3);


#
# TABLE STRUCTURE FOR: objekat_detaljan_cenovnik
#

DROP TABLE IF EXISTS objekat_detaljan_cenovnik;

CREATE TABLE `objekat_detaljan_cenovnik` (
  `objekat_detaljan_cenovnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `od` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `do` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena_za` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`objekat_detaljan_cenovnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: objekat_doba
#

DROP TABLE IF EXISTS objekat_doba;

CREATE TABLE `objekat_doba` (
  `objekat_doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `doba_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (9, 1, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (10, 1, 4);


#
# TABLE STRUCTURE FOR: objekat_iznajmljujese
#

DROP TABLE IF EXISTS objekat_iznajmljujese;

CREATE TABLE `objekat_iznajmljujese` (
  `objekat_iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `iznajmljujese_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (5, 1, 1);


#
# TABLE STRUCTURE FOR: objekat_karakteristike
#

DROP TABLE IF EXISTS objekat_karakteristike;

CREATE TABLE `objekat_karakteristike` (
  `objekat_karakteristika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `karakteristika_id` int(11) NOT NULL,
  `legenda_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_karakteristika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (77, 1, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (78, 1, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (79, 1, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (80, 1, NULL, 9, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (81, 1, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (82, 1, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (83, 1, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (84, 1, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (85, 1, NULL, 14, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (86, 1, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (87, 1, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (88, 1, NULL, 17, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (89, 1, NULL, 18, 3);


#
# TABLE STRUCTURE FOR: objekat_nacinplacanja
#

DROP TABLE IF EXISTS objekat_nacinplacanja;

CREATE TABLE `objekat_nacinplacanja` (
  `objekat_nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `nacin_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (3, 1, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (4, 1, 2);


#
# TABLE STRUCTURE FOR: objekat_razdaljine
#

DROP TABLE IF EXISTS objekat_razdaljine;

CREATE TABLE `objekat_razdaljine` (
  `objekat_razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `razdaljine_id` int(11) NOT NULL,
  `vrednost` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`objekat_razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (9, 1, 1, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (10, 1, 2, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (11, 1, 3, '3000');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (12, 1, 4, '400');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (13, 1, 5, '300');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (14, 1, 6, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (15, 1, 7, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (16, 1, 8, '60');


#
# TABLE STRUCTURE FOR: objekat_slika
#

DROP TABLE IF EXISTS objekat_slika;

CREATE TABLE `objekat_slika` (
  `objekat_slika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putanja` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `datum` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `velicina` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `glavna` int(11) NOT NULL,
  PRIMARY KEY (`objekat_slika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (4, 1, '', '9201.jpg', '1453217147', '102354', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (5, 1, '', '3396.jpg', '1453217148', '185994', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (6, 1, '', '3629.jpg', '1453217148', '86120', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (7, 1, '', '28514.jpg', '1453217148', '184661', 0);


#
# TABLE STRUCTURE FOR: privilegija
#

DROP TABLE IF EXISTS privilegija;

CREATE TABLE `privilegija` (
  `privilegija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `registracija` int(11) DEFAULT NULL,
  PRIMARY KEY (`privilegija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (1, 'Admin', 0);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (2, 'Premium korisnik', 1);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (3, 'Korisnik', 0);


#
# TABLE STRUCTURE FOR: rating
#

DROP TABLE IF EXISTS rating;

CREATE TABLE `rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `ocena` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (1, 1, '2');
INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (2, 1, '5');


#
# TABLE STRUCTURE FOR: razdaljine
#

DROP TABLE IF EXISTS razdaljine;

CREATE TABLE `razdaljine` (
  `razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (1, 'Od centra');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (2, 'Od plaze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (3, 'Od aerodroma');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (4, 'Od autobuske stanice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (5, 'Od ambulante');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (6, 'Od restorana');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (7, 'Od sportskih terena');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (8, 'Od prodavnice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (10, 'Od ski staze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (15, 'Od Žicare');


#
# TABLE STRUCTURE FOR: recnik
#

DROP TABLE IF EXISTS recnik;

CREATE TABLE `recnik` (
  `recnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr` text COLLATE utf8_unicode_ci NOT NULL,
  `en` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`recnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (2, 'Prijavi se', 'Log in');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (3, 'Početna', 'Home');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (4, 'Registruj se', 'Sign Up');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (9, 'Izaberite Drzavu', 'Choose Country');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (10, 'Registracija', 'Registration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (11, 'Zaboravili ste lozinku?', 'Frorgot your password?');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (12, 'Lozinka', 'Password');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (13, 'E-mail adresa', 'E-mail adress');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (14, 'Administracija Sajta', 'Website Administration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (15, 'Administracija Smestaja', 'Administration accommodations');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (17, 'Ime', 'Name');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (18, 'Prezime', 'Surname');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (19, 'ponovo', 'again');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (20, 'Opširnije', 'More');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (21, 'slika', 'pictures');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (22, 'Privatni', 'Private');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (23, 'Smestaj', 'Acommodation');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (24, 'Dobrodošli', 'Welcome');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (25, 'Pronadjite najbolje mesto za odmor', 'Find your best place for rest');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (26, 'Gde Hocete da idete?', 'Where you want to go?');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (27, 'Najposeceniji', 'Most visited');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (28, 'Smestaji', 'Accommodations');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (29, 'Smestajne jedinice', 'Accommodation units');


#
# TABLE STRUCTURE FOR: smestajnajed_slika
#

DROP TABLE IF EXISTS smestajnajed_slika;

CREATE TABLE `smestajnajed_slika` (
  `smestajnajed_slika_id` int(11) NOT NULL AUTO_INCREMENT,
  `smestajnajedinica_id` int(11) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putanja` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `datum` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `velicina` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `glavna` int(11) NOT NULL,
  PRIMARY KEY (`smestajnajed_slika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (11, 2, '', '20028.jpg', '1453217294', '49023', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (12, 2, '', '17690.jpg', '1453217295', '109184', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (13, 2, '', '2123.jpg', '1453217295', '110475', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (14, 2, '', '4648.jpg', '1453217296', '125184', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (15, 2, '', '6977.jpg', '1453217296', '109625', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (16, 3, '', '5346.jpg', '1453217476', '106923', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (17, 3, '', '6960.jpg', '1453217477', '67690', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (18, 3, '', '25513.jpg', '1453217477', '59494', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (19, 3, '', '7470.jpg', '1453217477', '57664', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (20, 4, '', '5803.jpg', '1453217573', '107060', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (21, 4, '', '16545.jpg', '1453217574', '67066', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (22, 4, '', '17094.jpg', '1453217574', '60260', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (23, 4, '', '29319.jpg', '1453217574', '72379', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (24, 4, '', '5556.jpg', '1453217575', '64148', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (25, 5, '', '25055.jpg', '1453218361', '55595', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (26, 5, '', '24821.jpg', '1453218362', '62548', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (27, 5, '', '7818.jpg', '1453218362', '69042', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (28, 5, '', '15611.jpg', '1453218362', '59918', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (29, 5, '', '8472.jpg', '1453218363', '78138', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (30, 6, '', '17714.jpg', '1453218452', '95422', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (31, 6, '', '3072.jpg', '1453218453', '55136', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (32, 6, '', '19513.jpg', '1453218453', '58722', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (33, 6, '', '638.jpg', '1453218453', '56358', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (34, 7, '', '22318.jpg', '1454261552', '595284', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (35, 7, '', '1116.jpg', '1454261553', '561276', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (36, 8, '', '4566.jpg', '1454261656', '879394', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (37, 8, '', '9028.jpg', '1454261657', '561276', 0);


#
# TABLE STRUCTURE FOR: smestajnajedinica
#

DROP TABLE IF EXISTS smestajnajedinica;

CREATE TABLE `smestajnajedinica` (
  `smestajnajedinica_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `broj_mesta` int(11) NOT NULL,
  `vrsta_id` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`smestajnajedinica_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (2, 1, 'Plava Cetvorokrevetna', 'Plava cetvorokrevetna', 4, 1, 1453215483, 1453217294, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (3, 1, 'Crvena trokrevetna', 'Crvena trokrevetna', 3, 1, 1453217476, 1453217476, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (4, 1, 'Roze dvokrevetna', 'Roze dvokrevetna', 2, 1, 1453217573, 1453217573, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (5, 1, 'Zuta dvokrevetna', 'Zuta dvokrevetna', 2, 1, 1453218361, 1453218361, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (6, 1, 'Narandzasta cetvorokrevetna', 'Narandzasta cetvorokrevetna', 4, 1, 1453218452, 1453218452, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (7, 1, 'gahahahsahs', 'ahsahahsahahsahsahs', 21, 1, 1454261552, 1454261552, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (8, 1, 'ggasgagas', 'asahsahsahsahs', 21, 2, 1454261656, 1454261656, 1);


#
# TABLE STRUCTURE FOR: tip
#

DROP TABLE IF EXISTS tip;

CREATE TABLE `tip` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO tip (`tip_id`, `naziv`) VALUES (1, 'Luksuzna Vila');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (2, 'Hotel');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (3, 'Kuća');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (4, 'Zgrada');


#
# TABLE STRUCTURE FOR: upit
#

DROP TABLE IF EXISTS upit;

CREATE TABLE `upit` (
  `upit_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `textupita` text COLLATE utf8_unicode_ci NOT NULL,
  `kontakt` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: upitdetaljno
#

DROP TABLE IF EXISTS upitdetaljno;

CREATE TABLE `upitdetaljno` (
  `upitdetaljno_id` int(11) NOT NULL AUTO_INCREMENT,
  `upit_id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upitdetaljno_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: usluge
#

DROP TABLE IF EXISTS usluge;

CREATE TABLE `usluge` (
  `usluge_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci,
  `cena` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`usluge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (1, 'Pozicija u mestu', '<p><span ><span ><strong ><em>dssssadsasagasga</em></strong></span></span></p>\r\n<h1><em><span><span><span><strong>&nbsp;</strong></span></span></span></em></h1>', '5');
INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (2, 'Premium paket', 's', '10');
INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (3, 'Premium paket + pozicija u mestu', 'a', '15');


#
# TABLE STRUCTURE FOR: vrsta
#

DROP TABLE IF EXISTS vrsta;

CREATE TABLE `vrsta` (
  `vrsta_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`vrsta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (1, 'Soba');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (2, 'Apartman');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (3, 'Studio');


