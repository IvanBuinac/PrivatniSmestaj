#
# TABLE STRUCTURE FOR: admin_poruke
#

DROP TABLE IF EXISTS admin_poruke;

CREATE TABLE `admin_poruke` (
  `admin_poruke` int(11) NOT NULL AUTO_INCREMENT,
  `poruka` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_poruke`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO admin_poruke (`admin_poruke`, `poruka`) VALUES (1, ' Ime:Marina Marković \n Email:mmmamarkovic@gmail.com \n Poruka:Poštovani,\n\nPokušala sam, nakon vašeg poziva, da postavim smeštaj na vašem portalu. Međutim, nisam uspela. izgleda da je neophodno da imamo sopstveni sajt za to? Da li je to tako? Prijavljeni smo na više turističkih portala, Booking.com, Tripadvisor i neke druge, i do sad nismo imali taj uslov da bismo se prijavili. Smeštaj nam je registrovan i kategorisan, vodi se na mog muža, ali sve on-line procedure obavljam ja.\n\nPozdrav, Marina Marković!');
INSERT INTO admin_poruke (`admin_poruke`, `poruka`) VALUES (2, ' Ime:Radovan Piljak \n Email:piljakr@gmail.com \n Poruka:Dobar dan.Hteo bih da se reklamiram preko vaseg sajta posto sam dobio ponudu,a posedujem kucu na Rosama.Hvala unapred');
INSERT INTO admin_poruke (`admin_poruke`, `poruka`) VALUES (3, ' Ime:ivan \n Email:ivke-92@hotmail.com \n Poruka:gasggasgas');
INSERT INTO admin_poruke (`admin_poruke`, `poruka`) VALUES (4, ' Ime:Šimun Martinis \n Email:apartmani.picasso@yahoo.com \n Poruka:Poštovani, zainteresiran sam da se preko Vas oglasim, tj svoje smještajne kapacitete u Hrvatskoj, tačnije na otoku Visu, grad Komiža, medjutim prilikom registracije jedina dva grada koja su ponudjena su Zagreb I Opatija. Šta da radim, i da li je registracija uopšte moguća?\n\nUnaprijed hvala\n');


#
# TABLE STRUCTURE FOR: cenausezoni
#

DROP TABLE IF EXISTS cenausezoni;

CREATE TABLE `cenausezoni` (
  `cenausezoni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cenausezoni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (1, 'Minimalna cena po osobi');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (2, 'Predsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (3, 'U sezoni');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (4, 'Postsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (5, 'Van sezone');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('072041f8f11dbf9ad072426358f73172', '24.135.100.76', '0', 1478708638, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0a591cc3e239b00305f860c048693836', '38.100.21.86', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36', 1478714802, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('222133ef030ebfa15af2bd9b56eb2a3e', '24.135.100.76', '0', 1478708333, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('30d86d9d83cf9645552668c467167bdd', '24.135.100.76', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 1478724067, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6c9f314594d31050b56994460c540f54', '24.135.100.76', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 1478724067, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a82a9939e6bd667ad8765ea7abca6021', '5.134.108.189', 'Mozilla/5.0 (Linux; Android 6.0; ALE-L21 Build/HuaweiALE-L21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.68', 1478723942, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('beb299280aacd7187be162e32a4aab0e', '24.135.100.76', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 1478724067, 'a:7:{s:9:\"user_data\";s:0:\"\";s:8:\"fb_token\";s:150:\"EAAOhy2UqTywBABzlsr8bX3HjBlkPSf1oRDrhehArsuR2WYG1VEm7X9u5mFtZAGbBZBID2pZAmCwzd908Sx1Cfg92YEuaOZClW9yGgnPt9MmjVDyXNmowhZAjkJ39FKlySdgfSJwNHs5o3PCjLotAJ\";s:3:\"ime\";s:4:\"Ivan\";s:5:\"email\";s:19:\"ivke-92@hotmail.com\";s:11:\"korisnik_id\";s:1:\"1\";s:14:\"privilegija_id\";s:1:\"1\";s:8:\"loggedin\";b:1;}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c89c8efcf910ef7ee0966fc4a73d6765', '24.135.100.76', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 1478724067, '');


#
# TABLE STRUCTURE FOR: doba
#

DROP TABLE IF EXISTS doba;

CREATE TABLE `doba` (
  `doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slika_obojena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slika_crno_bela` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (1, 'Zima', 'zima.png', 'zima_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (2, 'Leto', 'leto.png', 'leto_iskljuceno.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (3, 'Jesen', 'jesen.png', 'jesen_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (4, 'Prolece', 'prolece.png', 'prolece_iskljuceno.png');


#
# TABLE STRUCTURE FOR: dozvole
#

DROP TABLE IF EXISTS dozvole;

CREATE TABLE `dozvole` (
  `dozvole_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`dozvole_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (1, 'Pregled samo svojih smestaja');
INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (2, 'Ogranicen broj smestaja');
INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (3, 'Ogranicen broj slika u smestaju');
INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (4, 'Pregled samo svoji smestajnih jedinica');
INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (5, 'Ogranicen broj slika smestajnih jedinica');
INSERT INTO dozvole (`dozvole_id`, `naziv`) VALUES (6, 'Ogranicen broj smestajnih jedinica');


#
# TABLE STRUCTURE FOR: drzava
#

DROP TABLE IF EXISTS drzava;

CREATE TABLE `drzava` (
  `drzava_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `slika` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`drzava_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`) VALUES (1, 'Srbija', 'srbija', '44.03232064275084', '20.8245849609375', 7, 'Srbija', 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`) VALUES (2, 'Crna Gora', 'crna-gora', '42.819580715795915', '19.16839599609375', 8, 'Crna-gora-1', 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`) VALUES (5, 'Hrvatska', 'hrvatska', '45.39844997630408', '15.99609375', 7, 'Hrvatska-1', 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`) VALUES (6, 'Grčka', 'grcka', '39.8465036024177', '22.247314453125', 8, 'Grcka-1', 1);


#
# TABLE STRUCTURE FOR: grad
#

DROP TABLE IF EXISTS grad;

CREATE TABLE `grad` (
  `grad_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `slika` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `drzava_id` int(11) NOT NULL,
  PRIMARY KEY (`grad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (1, 'Beograd', 'beograd', '44.79085081250334', '20.457916259765625', 12, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (2, 'Igalo', 'igalo', '42.45541269782037', '18.506770133972168', 15, 'Igalo-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (4, 'Herceg Novi', 'herceg-novi', '42.45230964072516', '18.536295890808105', 15, 'Herceg-Novi-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (5, 'Kopaonik', 'kopaonik', '43.28542202482845', '20.807676315307617', 15, 'Kopaonik-1', 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (10, 'Budva', 'budva', '42.28594498725423', '18.84507179260254', 15, 'Budva-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (11, 'Podgorica', 'podgorica', '42.431312471126', '19.25731658935547', 13, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (12, 'Zagreb', 'zagreb', '45.805828539928356', '15.975837707519531', 12, 'Zagreb-1', 1, 5);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (13, 'Atina', 'atina', '37.96260604160774', '23.729782104492188', 11, NULL, 1, 6);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (14, 'Halkidiki', 'halkidiki', '40.455307212131494', '23.42010498046875', 9, NULL, 1, 6);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (15, 'Baošići', 'baosici', '42.44334790872497', '18.624916076660156', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (17, 'Bar', 'bar', '42.09083439530846', '19.091835021972656', 13, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (18, 'Djenovići', 'djenovici', '42.4359368863858', '18.608479499816895', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (19, 'Zelenika', 'zelenika', '42.45230964072516', '18.577194213867188', 16, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (22, 'Bečići', 'becici', '42.28327804780414', '18.87326717376709', 14, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (23, 'Bigova', 'bigova', '42.356990010542205', '18.704674243927002', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (24, 'Bijela', 'bijela', '42.453544549211614', '18.650236129760742', 14, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (25, 'Buljarice', 'buljarice', '42.19514212916286', '18.970041275024414', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (26, 'Čanj', 'canj', '42.16159021168176', '18.998494148254395', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (27, 'Dobre Vode', 'dobre-vode', '42.04731681680257', '19.14144515991211', 15, 'Dobre-Vode', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (29, 'Kotor', 'kotor', '42.42572154093003', '18.77042055130005', 16, 'Kotor-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (30, 'Zlatibor', 'zlatibor', '43.71900868001653', '19.696083068847656', 13, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (31, 'Žanjice', 'zanjice', '42.40010458893289', '18.58285903930664', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (32, 'Vranje', 'vranje', '42.54701017547381', '21.90047264099121', 13, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (33, 'Petrovac', 'petrovac', '42.20690493574547', '18.94263982772827', 15, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (34, 'Tivat', 'tivat', '42.433498024971726', '18.697915077209473', 15, 'Tivat-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (36, 'Krašići', 'krasici', '42.41053006572743', '18.644657135009766', 15, 'Krasici-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (37, 'Kumbor', 'kumbor', '42.440149241643034', '18.58762264251709', 15, 'Kumbor-1', 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (38, 'Opatija', 'opatija', '45.338994546401835', '14.30196762084961', 13, NULL, 1, 5);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (39, 'Tara', 'tara', '43.84727957287894', '19.45575714111328', 13, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (40, 'Bela Crkva', 'bela-crkva', '44.90160527494205', '21.421279907226562', 12, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (41, 'Palić', 'palic', '46.09275761636867', '19.74620819091797', 12, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (42, 'Srebrno jezero', 'srebrno-jezero', '44.75380406853624', '21.462135314941406', 12, NULL, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (43, 'Ulcinj', 'ulcinj', '41.93012373350468', '19.215946197509766', 14, NULL, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `slika`, `status`, `drzava_id`) VALUES (44, 'Komiža', 'vis-komiza', '43.04323722307614', '16.091537475585938', 14, NULL, 1, 5);


#
# TABLE STRUCTURE FOR: iznajmljujese
#

DROP TABLE IF EXISTS iznajmljujese;

CREATE TABLE `iznajmljujese` (
  `iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (1, 'sobe');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (2, 'studiji');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (3, 'apartmani');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (4, 'stanovi');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (5, 'ceo objekat');


#
# TABLE STRUCTURE FOR: kalendar_popunjenosti
#

DROP TABLE IF EXISTS kalendar_popunjenosti;

CREATE TABLE `kalendar_popunjenosti` (
  `kalendar_popunjenosti_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `ime_prezime` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cena` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `smestajna_jed_id` int(11) NOT NULL,
  PRIMARY KEY (`kalendar_popunjenosti_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (3, '2016-07-01', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (4, '2016-07-02', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (5, '2016-07-03', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (6, '2016-07-04', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (7, '2016-07-05', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (8, '2016-07-06', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (9, '2016-07-07', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (10, '2016-07-08', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (11, '2016-07-09', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (15, '2016-07-22', 'milosevic', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (16, '2016-07-23', 'milosevic', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (17, '2016-07-24', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (18, '2016-07-25', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (19, '2016-07-26', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (20, '2016-07-27', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (21, '2016-07-28', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (22, '2016-07-29', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (23, '2016-07-30', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (24, '2016-07-31', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (25, '2016-08-07', 'Elvisa', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (26, '2016-08-08', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (27, '2016-08-09', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (28, '2016-08-10', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (29, '2016-08-11', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (30, '2016-08-12', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (31, '2016-08-15', 'Valeri', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (32, '2016-08-16', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (33, '2016-08-17', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (34, '2016-08-18', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (35, '2016-08-19', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (36, '2016-08-20', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (37, '2016-08-21', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (38, '2016-08-22', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (39, '2016-08-23', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (40, '2016-08-24', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (41, '2016-08-25', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (42, '2016-08-26', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (43, '2016-08-27', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (44, '2016-08-28', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (45, '2016-08-29', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (46, '2016-08-30', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (47, '2016-08-31', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (48, '2016-09-01', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (49, '2016-09-02', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (50, '2016-09-03', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (51, '2016-09-04', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (52, '2016-09-05', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (53, '2016-09-06', '', NULL, 0, 6);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (62, '2016-07-10', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (63, '2016-07-11', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (64, '2016-07-12', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (65, '2016-07-13', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (66, '2016-07-14', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (67, '2016-07-15', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (68, '2016-07-16', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (69, '2016-07-17', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (70, '2016-07-18', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (71, '2016-07-19', 'Gabrijela', 7, 1, 4);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `cena`, `status`, `smestajna_jed_id`) VALUES (72, '2016-07-20', 'Gabrijela', 7, 1, 4);


#
# TABLE STRUCTURE FOR: kapara
#

DROP TABLE IF EXISTS kapara;

CREATE TABLE `kapara` (
  `kapara_id` int(11) NOT NULL AUTO_INCREMENT,
  `vrednost` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kapara_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (1, '5');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (2, '10');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (3, '15');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (4, '20');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (5, '25');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (6, '30');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (7, '35');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (8, '40');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (9, '45');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (10, '50');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (11, '55');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (12, '60');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (13, '65');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (14, '70');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (15, '75');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (16, '80');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (17, '85');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (18, '90');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (19, '95');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (20, '100');


#
# TABLE STRUCTURE FOR: karakteristike
#

DROP TABLE IF EXISTS karakteristike;

CREATE TABLE `karakteristike` (
  `karakteristike_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `chack` int(11) DEFAULT NULL,
  PRIMARY KEY (`karakteristike_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (1, 'Voda 24h', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (2, 'Pogodno za decu', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (3, 'Sef', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (4, 'Bazen', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (5, 'Obezbedjen parking', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (6, 'Garaža', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (7, 'Sobna usluga', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (8, 'Ljubimci dozvoljeni', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (9, 'Kablovska', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (10, 'Pogled na more', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (11, 'Kupatilo', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (12, 'Kuhinja', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (13, 'Balkon', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (14, 'Klima', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (15, 'Velika terasa', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (16, 'Internet', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (17, 'Televizor', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (18, 'Telefon u sobi', NULL);


#
# TABLE STRUCTURE FOR: kategorija
#

DROP TABLE IF EXISTS kategorija;

CREATE TABLE `kategorija` (
  `kategorija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kategorija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (1, '1 Zvezdica');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (2, '2 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (3, '3 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (4, '4 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (5, '5 Zvezdica');


#
# TABLE STRUCTURE FOR: korisnik
#

DROP TABLE IF EXISTS korisnik;

CREATE TABLE `korisnik` (
  `korisnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `privilegija_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grad` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `max_smestaja` int(11) DEFAULT NULL,
  `max_smestajnih_jed` int(11) DEFAULT NULL,
  `potvrda` int(11) NOT NULL,
  `rand` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  PRIMARY KEY (`korisnik_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (1, 1, 'Ivan', 'Buinac', 'ivke-92@hotmail.com', 'dbbf9cbeb1b31bb85b44d760a970d42048450b316b96f6acabe57206870e0cc6ef554e3c031fbc5a9befed6fe77e53870b84f985ff480373bf66c4f9bdb1945c', '1', 2, 0, 1, 1633582226, 1460842669, 1460842683);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (3, 2, 'Nebojsa', 'Jovanovic', 'hedonist@sbb.rs', 'bdb3075209c44ef90bb720664d8ed4f54851653d94f6fab811b1ec123da7b0220f5c7590d274e0f5ebc41660ca8b6703b04704f62e97bd14162f06ef4a434a61', '1', 1, 1, 1, 2051355246, 1461147867, 1461157177);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (5, 2, 'vinka', 'vujinovic', 'vinka.vujinovic@gmail.com', 'd1dfd4c80aac6e1d13016ccb97306e03b56e78042a5a5d7c5889ec2cc6c139fc24c6bbf667f270fe75ec0d1465918d724c025da20a406895030312a784a9d9ff', '33', 1, 1, 1, 1278956108, 1461619259, 1461619602);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (6, 2, 'Radomir', 'Rade', 'beograd808@gmail.com', '3466a0596f518bf3d596f5e7f533b4b93eca2d9bf629716981c5fbaa83326a54cb893abc2f251e0cd4efc46c7e252ddcb967911d3388aa7eac4995ef5269abe7', '1', 1, 1, 1, 586962157, 1461619339, 1464705895);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (7, 2, 'Ana', 'Lakicevic', 'anci2110@gmail.com', '412a6efa0f708f3574dec038411975fb78655a1c1edf563e262cbe2831193418f8c3d7e17030c5b8340a3c8d13145e1c9d5743cfe4f0f6cc56a77c8eed9bff2f', '29', 1, 1, 1, 2092614255, 1461619748, 1461619881);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (8, 2, 'Simo', 'Vorkapic', 'windsurf_hn@hotmail.com', 'ca157dfee153b96561f04b424a8e6071ff076c7b90412ab3ffcdb146ba015d6d8a72933f5f8c0cf3f2a6a78518e7446111e0a64fc6374fc1a88b99cd7ba8bcfc', '4', 1, 1, 1, 646392821, 1461620222, 1461620261);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (9, 2, 'Branislav', 'Buinac', 'bicomp@yahoo.com', 'ef099cd6ebb6c9d297107795a07f23c65c261900d6a4c7874483a76cedd1c7a30f17bafaf3c15c03c133f0e946660841c8d08cb0480048c74e4c1c900265f2ea', '1', 1, 7, 1, 1950218629, 1461620761, 1461754942);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (10, 2, 'Zoran', 'Vujicic', 'zoran.vujicic1@gmail.com', '5f6007d2e6d5eb3affd0de24f0f320b4732ee0d57e02babd34ed8eec92f9c4b2b6a6539a854077549ca85c7df8865169ae2e0c4748aef4db881e3aa1cf2892c1', '2', 1, 1, 1, 1404093209, 1461625105, 1461625121);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (11, 2, 'Boban', 'Bogdanovic', 'bog.boban1966@gmail.com', '6ab85757fff6c3257b2e4effaa92561beb5262acf9a7337ed87fe7c98afa0816e2bbb05f205f0ebec2ca2051d89588bde69af44425ce6cb7137cc4a5c7267065', '4', 1, 1, 1, 648682453, 1461652091, 1461694324);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (12, 2, 'Branka', 'Montenegro', 'nlmtravelbranka@gmail.com', '8a1fb729b3f0d35a912d9ba7331a166b6ef15a4fa12857bb355d18f442b46b28da1986258fde594261a488bf0e33874ef99f2dea9946d269a44b3ea27673c658', '10', 1, 1, 1, 1349466904, 1461652848, 1461652880);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (13, 2, 'Sara', 'Mrda', 'apartmanikrasici12@gmail.com', '5628e01f2c3ced4bf725fcb17a374e62264155db9bfd9116ea6b580bd5ca7fc5fb7a9c0415141ccda073a7b451e4dec0fa706fb0a6d642eaf2e8c45f9af99661', '29', 1, 1, 1, 2057317203, 1461653083, 1461655223);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (14, 2, 'dejan', 'reljic', 'apartmanpino@gmail.com', '54d9067e2d5cc59fad7e98637fca4e012d640a35cd47e90c8ed0cb53d9948a90aa6be509b1df318ebacd705677123433dad020c4c252c32c30fc9847655ab32c', '2', 1, 1, 1, 354244156, 1461656419, 1461656491);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (15, 2, 'marija', 'lakić', 'vukmar1306@gmail.com', '23e710a422b343ae30b538c70c5483edfd00e854e8c3c30758d47de540b73281254e9ad8b881a5e04f6dd0ef34d593cda9e9ffe97f3351723de53740c97c19c2', '34', 1, 1, 1, 193213819, 1461657431, 1461746670);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (16, 2, 'Slobo', 'Petkovic', 'apartman22tivat@gmail.com', 'c6d20108a9935548da6ecb6466f3cdf8717e2e5410532ae71d47adac83895e745c46e7a8f2f59a06bf43e0c9da4540f72cc4751e3c430cac76267e1383631989', '34', 1, 1, 1, 327901483, 1461663557, 1466195078);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (17, 2, 'zeljko', 'trojanovic', 'trojanovic.hercegnovi@gmail.com', '61f03dcea418f65c2da6f61f7d6b7634ff29717a9a0338759e45f05b9a7c810e040afaa213adf0f0a814d936e6fadcfe54ec426482b677f6ab99c4568e40d33e', '4', 1, 1, 1, 721886089, 1461666464, 1461863942);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (18, 2, 'Rajka', 'Vojinovic', 'rajkavojinovic@gmail.com', '16a425fa2ea55c2c102b034fa0b3c67630db7cb77fd1a05d0b9be9d0391f254bddcedcf70777c965f06f05914e85c4b85ad387d19de364b92df8359066563050', '10', 1, 1, 1, 431377123, 1461670934, 1461670993);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (19, 2, 'Jovana', 'Luburic', 'jovanaluburic@gmail.com', 'ff063e0b8d8fb0a99876ee2630f417f8c635f448dab70dec92b2ac9f1aabbeb3a767f3b80cd9c29efab3a94889f4df27bc2327bedeb60fa6b033bd85d5f21966', '33', 1, 1, 1, 915145129, 1461672353, 1461672438);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (20, 2, 'Marija', 'Bacelic', 'majaidunja2010@gmail.com', 'f96ab6a904aaf18a3376401ea3fbb46391310fb047660573a244874e492ad50d9c24d8d1c25ac06230d8799d6c0ab9be296604fb2901bb16fecd03f4befdd481', '2', 1, 1, 1, 1946988733, 1461672989, 1461673026);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (21, 2, 'marina', 'saraba', 'jeta@t-com.me', '3933a3ccb3e2dd303a7faa5af1cbe7ca2e66359cca7aed7ba96757147d23b4471a5b89a43c8dd486c88c6143607c6be58b171133324e0c066c89c5d529de2b11', '2', 1, 1, 1, 319116399, 1461745476, 1461768405);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (22, 2, 'Vesna', 'Borozan', 'borozan.vesna@gmail.com', 'a0aee6bd3d5752a10ab0b62f50267b0e3c7131653f7cad06a163a5bb22d68d245875cfea4380c32aa5ed8ac86aa9d3a3da27bd0856aefbedfbeceec5d4244fb5', '2', 1, 1, 1, 1636292630, 1461787307, 1461789733);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (23, 2, 'Marina', 'Marković', 'mmmamarkovic@gmail.com', '35a8b88c820414836b5da7c22429928df982253c2595ba78711ec3dcda8f72c2c8a3a6a433745a581045d876563adab30a017183e2248ebbbf3c642c05c83404', '10', 1, 1, 1, 888239364, 1461822403, 1461825359);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (24, 2, 'Svetlana', 'Kracun', 'svetlanakra@hotmail.com', '8d1e34be1ac2f74ba70926a3bf1c54a19703191219842c944e7ffe5c7dfd6c66fdb95af2d4a985e508e91359de8d02c6d95e12ab73ff5f5e3d04815203f7efa6', '10', 1, 1, 1, 1874882828, 1461849014, 1461849847);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (25, 2, 'Tanja', 'Gataric', 'postavljanjeoglasa@gmail.com', 'bf927d20ddb76ffe5435f1b8cd9cf8ec4f17e99dc9f749610837599a27241354c0d2d662877b1bc7a8db03afb37e1a08c5ed90740d290a110947ef0db62b0dcf', '1', 1, 1, 1, 304070729, 1461863524, 1461863559);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (26, 2, 'Vukasin', 'Petrovic', 'apartman.g10@gmail.com', 'c15c49a29e7b0c0526f3d7933f71d170d8b7e31aeae281e9e8b1f70270ac724c023e2751e541365d349cfdc9f3218a65608a2eddfadd39be035b19bb8193b647', '1', 1, 1, 1, 1655660107, 1461915252, 1461918863);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (27, 2, 'NENAD', 'ANTIĆ', 'antic@t-com.me', '32299f527b3185bda6a90131999a777e177ebd822395e4574f56ab686a20d1f3c079b0c27df1be04e3e179a3042ac0a1a8267c5479696d6a22f12adb26b9c62c', '10', 1, 1, 1, 2039151860, 1461933334, 1461933362);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (28, 2, 'Nadja', 'Djukic', 'djukic.nadja3@gmail.com', 'dc4eca99b3c42d77ea5ca0e980a2b4578098076d1d546f944b9c87cd66be5c5e47acf32eeacd852f8bfad8731e08b056054128e943f65f95763758849b5b09e6', '2', 1, 1, 1, 1748865259, 1462184386, 1462184489);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (29, 2, 'Branko', 'Prlainović', 'prlainovic@gmail.com', '7d57d60e3830287a50748e2004aa5e6d790d90e15dfbb67955984a3bce1844810596f66c5494dc189241bd5c7f5f77e3a750ca4e0168839c880fb12299c51aa4', '1', 1, 1, 1, 2049357991, 1462449459, 1462449470);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (30, 2, 'Radovan', 'Banicevic', 'rdblazo@gmail.com', 'ef9cc28e6affb7dbe970c121b059bb4cffeb2947e627ac0b3894cd452320e85b77e780bd96099d8244f7b74a527aece2ca5d88f99a5bd24affa44281fc9b1ec9', '29', 1, 1, 1, 766209651, 1466190884, 1466190921);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (31, 2, 'Snezana', 'Kovacevic', 'snezanakov@gmail.com', 'd3defdb9814336c27e92799b6d1e6f9c4ebb21357336f47b856fea1470a107fda656ac280134af55fe9c630e99ae8cee3ea7ab32aa120e6005052a438594a015', '10', 1, 1, 1, 1816823510, 1466190909, 1466190937);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (32, 2, 'Ana', 'Jovic', 'apartmanijovic@gmail.com', '20f84e26a68781d8a7d3f283aa07d272f1a62a32c545322a7c9c3518da7b88010fdf21410ebf96719d3a3a57cc5e97ba0536ce19840edd4468d3e9cc54482f2b', '0', 1, 1, 1, 920001331, 1466192177, 1466192249);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (33, 2, 'Marina', 'Blitvić', 'ivan.glavinic@du.t-com.hr', '504c19bccc367f118a9b116e4f9ca22d6027e2ca26c3c3f52e747b745737213750357420e36317c59f20164c93dffef749ab977cdad590e8e6a53fc5e39db806', '0', 1, 1, 1, 1656516264, 1466192298, 1466192336);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (34, 2, 'Nina', 'Pribilovic', 'nina.pribilovic@gmail.com', '7d3aec6eb723664896543f99b71859753502d74cef1989c2f71a1213c426f8398c6f3c30c15207a7d5773b732981b8790ff2e249a1b68da4c23129c30c4baebd', '10', 1, 1, 1, 141606440, 1466199286, 1466200866);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (35, 2, 'Miklos', 'Bošković', 'mlsboskovic@yahoo.com', '339449d11fc07cc8ca0a7fff11708e77634e8a4e9aa1d99ec4d71dfec055e739b0763998403db419d4a4649715afea55879a1643d77fda6945da66f7a6e42f0b', '10', 1, 1, 1, 1370894247, 1466200003, 1466200136);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (36, 2, 'gamaigalo', 'Valentic', 'apartman.igalo@yahoo.com', 'c05f6f6e112590a6e80b7a1c6f89e3f81b36bc1b7eb35d39ac5f5464fb48fe8178737b03b0a86c5c4190abbb2ae0d12807cba61df4a4d9e21db3da7464b18b82', '2', 1, 1, 1, 370739833, 1466231037, 1466231061);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (37, 2, 'Mile', 'Igalo', 'moreig.hn@gmail.com', '6770cf6a2c28a7c7ff5e9b1f03f711ddaf8453e0dd208cfe5716185d6a918a8912fa76ac41887c744e419762735d4c1dc27d217bf8a7b32adf5371cef967a18b', '2', 1, 1, 1, 414183567, 1466231962, 1466232156);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (38, 2, 'Aleksandar', 'Petković', 'aleksandar_petkovic@hotmail.rs', '7098a8aa4381ab45af4b6c2d0041f69c4bda2e2891b59e828b246e3cbf5a1b6117f7dde31bfebfd43c0dee59423070c1dcc53d1fb40abfdffb84499fd250ea7f', '2', 1, 1, 1, 933605482, 1466237911, 1466238645);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (39, 2, 'Dejan', 'Radonic', 'dejanradonjic86@gmail.com', '5adcbf0ec12f7abc4261fb82ae50e80b01bfdaadef36de21ce49cc09cda4f3f40b6eff4f936c586e4297cea8c00a492b66bb6ced9bad534bc3e16ccd3f2f698e', '34', 1, 1, 1, 681068631, 1466239226, 1466239484);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (40, 2, 'Nataša', 'Mičić', 'apartmanikrasici5@gmail.com', '05e9aa3ac6c06b7cefca5bce9ee3579041dd6a7f0bb6b5cd00790b15fb77da84e0b2fa67969c67e78aeb9eed29ec68ad7cfe58ba6fcf83c37928c92ac07b4d29', '36', 1, 1, 1, 2122185677, 1466267054, 1466267072);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (41, 2, 'Krsto', 'Pribilović', 'backobd@yahoo.com', '0898f6d02403e72a5abc8b6c8d494370b1f0ca467c04d2a0dd775fa29acddfdfa02a3799875d1706fd0835fcf0a019640f6319fc6f51d35ba6f8421935961469', '10', 1, 1, 0, 1428967917, 1466498859, 1466498859);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (42, 2, 'Mirjana', 'Ivanovic', 'mirjanatehnolog@gmail.com', '2cdcc13fad050a8382ec70adba87337c27aa450b10f87dbd70603bf9370f6e6ce56bb42359c7747884b11c39b3d73ff265a261d97afc9d5d3cbec7dba35df529', '4', 1, 1, 1, 1707378170, 1466595933, 1466601528);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (43, 2, 'Luka', 'Lucic', 'lucke91@yahoo.com', '04df0a159c7d3a5844be1954ec76c19c389861c0829cbe4569b066f3e45ded77940e4d038262c190be3f5d0e81b8e0e8a8e8cc85cac50ac332c65c8de930133c', '27', 1, 1, 1, 461925113, 1467803884, 1467804001);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (44, 2, 'Sneža', 'Petrović', 'sneza.petrovic92@gmail.com', NULL, '', 1, 1, 1, 231737177, 1468421218, 1468421218);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (45, 2, 'Milos', 'Ivancevic', 'milos.i@hotmail.com', 'a344051a666b92bef3201102bcb66b3dbecbbdb7bd221b49db3dd8825ded489d58884e9de0f4e9bbd12778550820aa939e8e86e1670029294b3e573d738a6f65', '2', 1, 1, 1, 741275446, 1468613052, 1468654981);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (46, 2, 'Marko', 'Jokic', 'apjokic@gmail.com', 'ef099cd6ebb6c9d297107795a07f23c65c261900d6a4c7874483a76cedd1c7a30f17bafaf3c15c03c133f0e946660841c8d08cb0480048c74e4c1c900265f2ea', '34', 1, 1, 0, 1696614944, 1469557424, 1469557424);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (47, 2, 'Radovan', 'Piljak', 'piljakr@gmail.com', '10c2e8222185a561c605d595d5bda3328ff166d35e71305e58d52f245590365152b93d392f3e28f5c46f0fa4f0cfd1f256f1bd680ffe6b1ceba4d11b76e36662', '0', 1, 1, 1, 129969553, 1469696537, 1469854625);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (48, 2, 'Sanja', 'Kipić', 'sanjaigalo@gmail.com', 'ca58ac67c8d4e70f37d7c95d7b4f246975f2b3f6fa7bf0ec8cee01a65f690a4e8d438cd1f0986f371f166c8fc03c631ea56ee6a3cc402c01f56000c5a00210ed', '2', 1, 1, 1, 543022012, 1469775690, 1469775710);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (50, 2, 'Guest House', 'Villa Dalila', 'dalila@t-com.me', NULL, '', 1, 1, 1, 2101561743, 1476213479, 1476213479);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (51, 2, 'New Line', 'Travel', 'newlinetravel.booking@gmail.com', '3209032e022237994e6697fd329d04ce5bfcb196f651fdb0fb58c0f47011f3dd2792b1032f04d1cfded8975f5e13e85601500fb2026229a99f372a77cfa1fdd7', '10', 1, 1, 0, 2142770203, 1476213784, 1476213784);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (52, 2, 'milos', 'momcilovic', 'vila.madams@yahoo.com', 'e7833e26912b2c66cd7d124896fed5748d41a8efbb2358b2ccfa1d1a0f781b91573c6e1d61007a5ecd256a6215d5914e5075d1b770749a86b65fa75ae2128b3f', '41', 1, 1, 0, 505452802, 1476252157, 1476252157);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (53, 2, 'zvonko', 'perica', 'tezina@net.hr', '3ae9b81f0f62904e402d1162cbfad2de6d9e2620d9f5c849e0f7c0baa450a22463dd6c0d4b6cd01d5a6addaa2c713ec6411cef7da87bfc30c659043cf18432e4', '12', 1, 1, 0, 978974123, 1476255280, 1476255280);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (54, 2, 'Aleksandar', 'Kopitović', 'apartmanikopitovic@gmail.com', 'f627972a6d68f9d5495c3175e22dec5638c666c569163ffc4447490ee35a3212d016b9f07d9284b861a06eb03777bc55d80b5fa1913a8de7ea87126756c98121', '33', 1, 1, 1, 841772462, 1476278216, 1476278249);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (55, 2, 'Milena', 'Velanac', 'velanacm@gmail.com', '83d919a6c64373d62b35942f6e3e8228c20136c648a108fb88331bba7a762ef81350995f94cd9b8fca42737792cab6b1a421da69cd089a9f435d067f0e2a45f1', '30', 1, 1, 1, 984133141, 1476335780, 1476337710);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (56, 2, 'Miroslav', 'Perovic', 'vilaparaglajder@gmail.com', 'dece1df44cd5b210713dedc1113150ae9fdd4afecb89627e383abd329005bbc0b01f3e758ffc77ce81d369cb8f6026967c2e6a10b3f966d7814b14013e012b38', '1', 1, 1, 1, 608515211, 1476628001, 1476628014);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`, `kreiran`, `modifikovan`) VALUES (57, 2, 'Šimun', 'Martinis', 'apartmani.picasso@yahoo.com', 'c1b6fe0678903e1f77094eec19d9e2ee8fe3027d5c99a8eceb4921f90aa08f4466f0c58d5c06852cd22eab565c20a965ed1d1d658f3a876877f6f7174707be8d', '44', 1, 1, 1, 1201479915, 1478241630, 1478241658);


#
# TABLE STRUCTURE FOR: korisnik_kontakt
#

DROP TABLE IF EXISTS korisnik_kontakt;

CREATE TABLE `korisnik_kontakt` (
  `korisnik_kontakt_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnik_id` int(11) NOT NULL,
  `telefon` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`korisnik_kontakt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (1, 1, '+381605137947');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (2, 2, '+38269917103');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (3, 3, '+38163335146');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (4, 4, '0605137947');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (5, 5, '+38268208058');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (6, 6, '066409800');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (7, 7, '0038269825823');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (8, 8, '063');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (11, 10, '00382069041332');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (13, 12, '+38269977221');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (15, 11, '068044855');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (16, 13, '0637304966');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (17, 14, '+38269668432, +38267875866');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (22, 18, '0038269479909');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (23, 18, '0038267811117');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (27, 19, '0038267315470');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (28, 20, '+38268530106');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (31, 17, '+38267802033');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (32, 21, '0038268633120');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (33, 15, '0038267201307');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (34, 9, '0600280251');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (35, 9, '068711787');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (38, 22, '0679215939');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (43, 23, '00381637236277');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (44, 24, '+38268507585');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (45, 25, '0694497531');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (49, 26, '+381 (0)64 222 42 32');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (50, 27, '067666766');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (51, 28, '0603625644');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (52, 29, '0692580011');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (53, 30, '0038269123099');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (54, 31, '063580611');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (55, 32, '00385915026893');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (56, 33, '00385918945796');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (57, 16, '068625035');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (59, 35, '+38267672841');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (60, 34, '069867143');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (61, 36, '+382 67 443 213');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (62, 37, '067207242');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (63, 38, '0038765150721');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (66, 39, '+38269255622');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (67, 40, '0038765638942');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (68, 40, '0038765833078');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (69, 41, '0642156835');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (71, 42, '+38267224485');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (72, 43, '+38267417143');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (73, 45, '+38263409104');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (74, 45, '+38765281032');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (75, 46, '+38269264520');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (76, 47, '00381605531082');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (77, 48, '+382 68 205 448');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (78, 48, '+382 69 532 778');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (79, 49, '0605137947');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (80, 51, '+382 69977221');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (81, 52, '0600754951');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (82, 53, '098977272');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (83, 54, '+381641725601');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (84, 54, '+38269576033');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (85, 55, '064 40 79 629');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (86, 56, '063237081');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (87, 56, '063309101');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (88, 57, '+385992364565');


#
# TABLE STRUCTURE FOR: legenda
#

DROP TABLE IF EXISTS legenda;

CREATE TABLE `legenda` (
  `legenda_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `slika` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`legenda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (1, 'Svaka soba, apartman', 'yes.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (2, 'Neke sobe, apartmani', 'maybe.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (3, 'Nema', 'no.png');


#
# TABLE STRUCTURE FOR: link
#

DROP TABLE IF EXISTS link;

CREATE TABLE `link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `meni_id` int(11) DEFAULT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tezina` int(11) DEFAULT NULL,
  `roditelj` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (1, 1, 'Početna', '', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (2, 2, 'Linkovi', 'admin/administracija_linkova', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (3, 3, 'Administracija Smestaja', '', 1, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (4, 3, 'Administracija smestaja', 'korisnik/smestaji', 1, 3);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (5, 3, 'Administracija smestajnih jedinica', 'korisnik/smestajne_jedinice', 1, 3);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (6, 3, 'Upiti', 'korisnik/upiti', 1, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (7, 3, 'Svi upiti', 'korisnik/upiti/', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (8, 3, 'Obradjeni', 'korisnik/upiti/obradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (9, 3, 'Neobradjeni', 'korisnik/upiti/neobradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (10, 3, 'Poslati', 'korisnik/upiti/poslati', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (13, 3, 'Moj Profil', 'korisnik/moj_profil', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (14, 2, 'Pretraga', '', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (15, 2, 'Meniji', 'admin/administracija_menija', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (16, 2, 'Dashboard', 'admin/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (17, 2, 'Gradovi', 'admin/administracija_gradova', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (18, 2, 'Drzave', 'admin/administracija_drzava', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (19, 3, 'Dashboard', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (20, 2, 'Doba', 'admin/administracija_doba', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (23, 2, 'Korisnici', 'admin/administracija_korisnika', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (24, 2, 'Smestaji', 'admin/administracija_smestaja', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (26, 2, 'Administracija smestaja', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (27, 2, 'Smestajne jed', 'admin/smestajne_jedinice', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (28, 0, 'Kalendar popunjenosti', 'korisnik/kalendar_popunjenosti', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (29, 0, 'backup_database', 'admin/dashboard/backup_database', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (30, 2, 'Usluge', 'admin/usluge', 0, NULL);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (31, 2, 'Mailing', 'admin/mailing', NULL, NULL);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (32, 3, 'Uputstva', 'korisnik/uputstva', NULL, NULL);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (33, 3, 'Smestaja', 'korisnik/uputstva/smestaja', NULL, 32);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (34, 2, 'Dozvole', 'admin/dozvole', NULL, NULL);


#
# TABLE STRUCTURE FOR: meni
#

DROP TABLE IF EXISTS meni;

CREATE TABLE `meni` (
  `meni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`meni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO meni (`meni_id`, `naziv`) VALUES (1, 'Gornji Meni');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (2, 'Administracija menija');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (3, 'User_meni');


#
# TABLE STRUCTURE FOR: menu_privilegija
#

DROP TABLE IF EXISTS menu_privilegija;

CREATE TABLE `menu_privilegija` (
  `menu_privilegije_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `privilegije_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_privilegije_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO menu_privilegija (`menu_privilegije_id`, `menu_id`, `privilegije_id`) VALUES (1, 3, 2);
INSERT INTO menu_privilegija (`menu_privilegije_id`, `menu_id`, `privilegije_id`) VALUES (2, 3, 3);
INSERT INTO menu_privilegija (`menu_privilegije_id`, `menu_id`, `privilegije_id`) VALUES (3, 3, 1);
INSERT INTO menu_privilegija (`menu_privilegije_id`, `menu_id`, `privilegije_id`) VALUES (4, 2, 1);


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO migrations (`version`) VALUES (7);


#
# TABLE STRUCTURE FOR: nacinplacanja
#

DROP TABLE IF EXISTS nacinplacanja;

CREATE TABLE `nacinplacanja` (
  `nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slikauboji` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `crnobela` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (1, 'Keš', 'kes.png', 'kes-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (2, 'Bankovni transfer', 'TBanks.png', 'TBanks-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (3, 'Kreditna kartica', 'kartica.png', 'kartica-black.png');


#
# TABLE STRUCTURE FOR: novosti
#

DROP TABLE IF EXISTS novosti;

CREATE TABLE `novosti` (
  `novosti_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`novosti_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1048 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO novosti (`novosti_id`, `email`) VALUES (1002, ' beksa04@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (48, ' bugida@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1004, ' caka27@hotmail.co.uk');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (693, ' damir.plitvice@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (648, ' darko.mazi@ri.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (765, ' dragan.ferderber@gs.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (595, ' info@kavourakia.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (453, ' info@poseidon-jaz.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (998, ' info@vilabaroviczlatibor.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (950, ' ivana101@mts.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (497, ' makipop@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (682, ' marija.toic@ri.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (149, ' mirjanatehnolog@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (175, ' mitrovicvladimir@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (961, ' rzjzboj@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (620, ' sdanes21@aol.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (139, ' vukcevic2012@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (673, ' zeljko.petkovic@si.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (512, 'abt@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (997, 'admtjovanovic@bluewin.ch');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (536, 'adriacoast@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (518, 'adriasun@adriasun.sk');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (40, 'adzic.apartments@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (47, 'adzicstanka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (134, 'akuigla@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (555, 'alaketic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (182, 'aleksandar_petkovic@hotmail.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (991, 'aleksandar.ducic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (255, 'alekstravel_montenegro@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (827, 'alex.goljovic.zlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (802, 'alex.goljovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (335, 'alex.imsir@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (131, 'alexandarsuites@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (273, 'alkont.ag@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (547, 'ana.skundric@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (979, 'ana@vilazip.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (321, 'anacentar@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (582, 'anarizon@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1040, 'anastazi@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (329, 'anci2110@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (694, 'andelka.rubic@inet.hr; hrubic@inet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (958, 'andjamiljanic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (400, 'angelogabriel@hotmail.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (429, 'aniapartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (490, 'anicavasiljevic@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (787, 'anita.ivanic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (734, 'anita.miletic@zd.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (363, 'anita.s@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (664, 'anitakocijan@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (618, 'anka.danolic@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (61, 'ankabecanovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (730, 'ankica.kristic1@zg.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (750, 'ankicaresetar55@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (652, 'antebari@inet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (23, 'antic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (685, 'apart.just@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (202, 'apartman.igalo@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (320, 'apartman22tivat@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (877, 'apartman73@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (984, 'apartmanambijent@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1011, 'apartmandora@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (241, 'apartmani_felix@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (654, 'apartmani_kelava@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (799, 'apartmani.anja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (455, 'apartmani.becici@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (819, 'apartmani.bucevac@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (680, 'apartmani.dutkovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (340, 'apartmani.ivosevic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (511, 'apartmani.markovic.igalo@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (242, 'apartmani.ota@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (738, 'apartmani.picasso@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (631, 'apartmani.posavec@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (797, 'apartmani.prestige@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (580, 'apartmani.radulovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (681, 'apartmani@apartmani-dutkovic.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (954, 'apartmani@apartmani-rajevac.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (55, 'apartmani@damonte.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (239, 'apartmaniamor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (33, 'apartmanibonus@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (341, 'apartmanibrkan2@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (651, 'apartmanibulat@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (660, 'apartmanidariovrsi@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (838, 'apartmanidelic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (284, 'apartmanidragovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (905, 'apartmanigardos@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (156, 'apartmaniigalo000@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (831, 'apartmanikatarina@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (477, 'apartmanikezman@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (318, 'apartmanikrasici12@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (347, 'apartmanikrasici5@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (796, 'apartmanimaji@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (201, 'apartmanimarina.me@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (346, 'apartmanimazina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (153, 'apartmaniobalameljine@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (860, 'apartmaniplanina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (817, 'apartmaniradosti@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (911, 'apartmanisremac@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (322, 'apartmanitivat@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (881, 'apartmaniudovicic@ymail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (27, 'Apartmanivilaodmor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (228, 'apartmanivujicic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (244, 'apartmanpino@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (742, 'apartment_dobra@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (375, 'apartments.mne@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (369, 'apjokic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (982, 'apopovicc@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (754, 'app-rincic@email.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (617, 'appboljat@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (779, 'apt-grguric@horizon-system.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (426, 'arabelovic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (501, 'ararat@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (191, 'arnautovic@m-kabl.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (712, 'artur.polajner@sk.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (46, 'astevic10@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (491, 'atlasglob.tour@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (6, 'auna@nadlanu.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (5, 'auna@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (629, 'aurelija.sikiric@marinadalmacija.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (366, 'aurora@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (880, 'avramovic-94@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (581, 'azurbudva@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (29, 'backobd@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (246, 'bakrac2001@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (861, 'banelli75@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (925, 'barbaive@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (662, 'barbel.jurac@zd.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1047, 'bbcomp09@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (111, 'bdapartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (959, 'beksa04@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (825, 'bella.vista.zlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (566, 'belmare@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (707, 'BENDA.MARCELA@GMAIL.COM');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (913, 'beograd011apartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (478, 'biblioteka-igalo@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (274, 'bili@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (105, 'bismontenegro@live.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (526, 'biuro@czarnogora-apartamenty.pl');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (143, 'bjbokica2@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (778, 'blanka.grguric@zd.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (715, 'blazenka.hodak@ka.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (469, 'blazoradjenovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (704, 'bmaravic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (91, 'bmw.cg@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (122, 'bnevena83@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (147, 'bog.boban1966@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (381, 'bogumila@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (302, 'bojanamedigovic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (908, 'bojanamisa@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (60, 'bojanavujadinovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (225, 'bojankingking@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (205, 'bojanst@live.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (399, 'bokicas@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (39, 'booking@adrovic.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (760, 'booking2012.hr@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (200, 'borozan.vesna@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (833, 'boskova.voda@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (626, 'bozidarnizic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (15, 'brankahrstic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (127, 'brcupic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (657, 'brodica@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (902, 'bubamara.pescara@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (252, 'bubavulas@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (100, 'budvaapart@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (545, 'bujdoso.gergely@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1001, 'bula43@mts.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (144, 'bum@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (72, 'carevici@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (947, 'casaresidenziale@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (379, 'cedas@sbb.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (353, 'chanko@bluewin.ch');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (168, 'cinicla6@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (427, 'cirko@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (350, 'city.apartment@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (397, 'contact@montenegro-apartment.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (587, 'contact@pension-antonakis.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (803, 'contact@topview.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (54, 'cuca307@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (558, 'cuckovicelektro@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (316, 'cules@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1039, 'cuma33@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (989, 'cveticanin.bojana@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (2, 'd.roki@live.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (869, 'dabic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (148, 'dacaevropa@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (257, 'dada.jeka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (541, 'dalilamne@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (851, 'dallazarevic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (627, 'damir.nizic@ri.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (194, 'damjanacjelena@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (152, 'damjanovic.misko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (671, 'danica.bicanic@gs.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (687, 'danica.zderic@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (262, 'daniela.tasees@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (872, 'danijela.bogdanovic87@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (181, 'danijela.tfc@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (166, 'daniloadzicnk@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (99, 'danilokojic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (824, 'dankakeric@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1005, 'dansostar@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (234, 'dapeace@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (435, 'darko0303@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (94, 'david.dada26@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (109, 'dejan.andjusic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (343, 'dejan.miraihouse@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (504, 'dejanreljic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (41, 'dejanzivanovic.5@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (260, 'dejohn_86@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (272, 'deki.k@eunet.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (759, 'den.moro@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (744, 'denis.ivas@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (758, 'denmorov@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (513, 'designbvr@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (832, 'dexadejan@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (442, 'dianar@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (95, 'dijana.bd@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (841, 'dimitrijevicdusan525@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (907, 'director@apartmanisingidunum.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (900, 'direkcijajpbc@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (999, 'djo.teo@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (247, 'djukic.nadja3@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (563, 'dolcino@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (564, 'dotlic@net.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (622, 'dragan.bicanic@gs.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (623, 'dragan.bicanic25@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (723, 'dragan.ferderber@gs.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (8, 'dragan.stanojevic73@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (890, 'dragan@vilabajka.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (83, 'dragana.budva@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (155, 'draganajargic29@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (165, 'draganamendegaja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (93, 'dragoljub2008@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (419, 'dragsi@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (739, 'drasko.tecic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (645, 'drazen.ujdur@st.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (644, 'drazen.ujdur@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (485, 'drim@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (583, 'ds@mpfinvestments.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (275, 'dsnpenda@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (642, 'dubravko.peranic@ri.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (531, 'dudabulatovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (883, 'dunjaa94zl@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (448, 'durdev@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (292, 'durdevic@btinternet.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (437, 'dusan_vukasovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (319, 'dusant24@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (110, 'dusanzlatanovic26@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (410, 'dz-busatlic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (24, 'dzogi@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (592, 'edita.kachlova@volny.cz');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (927, 'elbarcoapartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (224, 'emac@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (295, 'endlesssport@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (801, 'erosapartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (616, 'falkusa@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (667, 'fanimusulin02@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (858, 'filip.asterix@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (884, 'filipovic.gvozden@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (557, 'gahealy@eircom.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (522, 'gaksentijevic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (844, 'garantnekretnine@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (456, 'gavica@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (688, 'gberislav@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (956, 'georges_sande@msn.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (392, 'gimo@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (336, 'glamocaningoran@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (380, 'glavanovic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (313, 'globarevicmilic14@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (32, 'gocagoca57@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (196, 'godra07@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (307, 'goran_sugic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1041, 'gorancelikovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (394, 'gortandana@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (591, 'gplatamon@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (544, 'grandino.ul@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (470, 'grkovic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (659, 'grozdana.milling@pu.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (960, 'gtlight.ue@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (611, 'hanja70@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (56, 'hedonist@sbb.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (256, 'hercegnovi_boka2012@hotmail.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (755, 'hmlinaric@vip.hr; vip-vip@vip.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (745, 'holidays@vip.hr;darel.rak@vip.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (808, 'horizont1966@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (218, 'hotel-monako@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (403, 'hotel-riva@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (565, 'hotel.aleksandar@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (488, 'hotel.castellamare@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (895, 'hotel.president@seval.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (285, 'hotel.renome@mail.ru');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (879, 'hotel@mons-zlatibor.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (505, 'hoteladrovic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (411, 'hotelanastazija@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (51, 'hotelgrbalj@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (896, 'hoteliriszlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (439, 'hotelmax@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (120, 'hotelmena@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (705, 'house.ema@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (975, 'idivanamb@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (219, 'igalo.leto@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (245, 'igalopromet@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (212, 'igorarna@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (863, 'igorcajetina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (726, 'ilija.krizmanic@ka.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (438, 'ilir_perezaj@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (69, 'info_raymond@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (599, 'info@annapartments.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (686, 'info@apartmani-bilen.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (625, 'info@apartmani-niko.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (42, 'info@apartmanibecici.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (70, 'info@apartmanibutua.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (367, 'info@apartmanilastva.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (847, 'info@apartmanimilekic.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (267, 'info@avant-garden.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (264, 'info@bakazlata.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (64, 'info@budva-apartments-davor.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (240, 'info@david-apartmani.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (826, 'info@dunavturist.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (458, 'info@firenze-ulcinj.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (572, 'info@forterose.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (287, 'info@gregovic-apartments.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (677, 'info@hodak.net;ana@hodak.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (600, 'info@hotel-makedonia.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (301, 'info@hoteldelmar.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (294, 'info@hoteldjuric.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (126, 'info@hotelfineso.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1046, 'info@hotelidila.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1045, 'info@hotelmirzlatibor.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (909, 'info@hotelzeder.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (401, 'info@in-booking.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (593, 'info@lataniacretehotel.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (700, 'info@matijasic.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (809, 'info@milosevkonaktara.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (703, 'info@mise-croatia.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (731, 'info@ozis.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (590, 'info@papakosta.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (390, 'info@perladimontenegro.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (500, 'info@philiahotel.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (784, 'info@pixma-centar.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (28, 'info@poseidon-jaz.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (843, 'info@romantika.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (588, 'info@samonas.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (548, 'info@svetistefan.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (624, 'info@tc-marko.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (830, 'info@vilaborova.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (919, 'info@vilaverona.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (601, 'info@villa-christinas.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (467, 'info@villa-ferri.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (371, 'info@villakristina.org');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (569, 'info@villaslapcici.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (962, 'info@zlatibor.org.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (878, 'info@zlatiborskiapartmani.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (846, 'info@zlatiborskivisovi.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (214, 'institutprvafaza@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (524, 'INTERNOS@T-COM.ME');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (515, 'irenaradunovic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (291, 'itt.milocer@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1, 'ivan.buinac.182.11@ict.edu.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (788, 'ivan.glavinic@du.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (679, 'ivan.kotarski1@zg.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (782, 'ivana-opravic@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (621, 'ivana.bakmaz@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (747, 'ivana.resetar@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (684, 'ivana1603@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (466, 'ivanabal@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (783, 'ivanacuk74@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (789, 'ivanaskarica@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (345, 'ivankab@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (278, 'ivanrakocevic26@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (974, 'ivanue74@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (472, 'ivarina@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (211, 'ivavucinic5@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (636, 'ivica.jujnovic@strabag.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (103, 'ivilimon@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (378, 'ivke-92@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (293, 'ivtina66@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (507, 'ivtours@cg.yu;ivtours@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (288, 'izdavanjepetrovac@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (678, 'j.babaja@vip.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (63, 'jablan.b@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (82, 'jadramon@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (489, 'jadrankaproperty@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1033, 'janvir@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (665, 'jaquelineb@home.se');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (882, 'jasamkatarina@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (85, 'jasmina.janjic69@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (709, 'jasna.ljubas@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (137, 'jejaitasa9@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (77, 'jelenapachouly@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (138, 'jelenas2405@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (887, 'jelicicjovana@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (235, 'jelovac2001@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (199, 'jeta@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (955, 'jevtic.vlade@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (445, 'jjt@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (506, 'jkuljaca@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (781, 'jlovorka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (308, 'jmaksimovic1@sbb.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (354, 'jovanka.celenovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (331, 'jovanmr@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (663, 'jovicicici@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (62, 'jovicivan35@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (342, 'jpejovic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (577, 'jradivoj@eunet.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (420, 'jrajo@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (413, 'jvpetric@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (36, 'k5plus@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (874, 'kaleema.jov@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (452, 'karanikic80@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1028, 'karaula77@mts.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (655, 'karmen.toic.dlacic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (717, 'katarina.ruzicka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (836, 'katarina02kokorovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (640, 'katicaboric25@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (443, 'klio@t-com.me; acolalovic88@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (190, 'kolani888@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (553, 'koljai@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (4, 'kop.sun.ski@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (11, 'kopaonik2010@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (7, 'kopaonikapartmani@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (724, 'kordic@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1027, 'kovacevic_nikola@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (269, 'kovacevicapartmani@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1007, 'kovacevicslavoljub@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (67, 'krivokapicg@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (502, 'krivokapics@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (656, 'Kruzic.ana@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (735, 'ksenija_stipcic@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (575, 'kucagusara@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (431, 'kurtagic_ismeta@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (297, 'kyla4silberfox@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (414, 'ladaniella@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (310, 'lazar_22ksh@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (537, 'lazar.mihajlovic41@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (862, 'lazartrisovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (383, 'lazopop@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (124, 'lelek@teol.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (666, 'lelija.rubic@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (173, 'letovanje.apartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1006, 'lightzr@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (768, 'lija.krizmanic@ka.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (630, 'lili711@windowslive.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (834, 'ljilja983@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (901, 'ljiljanamilenkovic@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (701, 'ljubo@dusper.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (702, 'ljubodusper@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (899, 'ljubomir_josic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (749, 'loccodeia@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (382, 'lolodibra@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (928, 'luigiluxserbia@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (893, 'luka.vesovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (638, 'luka.vukman1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (112, 'lukaf@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (805, 'lupusz@eunet.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (406, 'luxapartmani@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (277, 'luxapartment@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (898, 'm.milossss@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (496, 'm.popovic@barplov.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (794, 'm.vidic@apartmanimonaco.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (706, 'magdalenapalian@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (180, 'majaidunja2010@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (584, 'majonig@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (58, 'makarios298@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (396, 'malavrazic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (632, 'mambrus65@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (554, 'manik@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (561, 'maraharasho@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (483, 'marea@marea.cz');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (708, 'marica.dukic@ka.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (606, 'marija.brajdic1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (695, 'marija.rakigija@du.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (206, 'marijab90@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (675, 'marijan.badanjak@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (326, 'marina.radojicic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (628, 'marinela.n@hi.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (670, 'marinko.corak1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (732, 'mario.simek@ck.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (270, 'marisapartmani@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (534, 'markgak@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (676, 'markiczarko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (746, 'marko.brgic@pu.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (434, 'marko.p@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (722, 'marko.salopek1@ka.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (10, 'markoh8@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (351, 'markusnekretnine@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (568, 'marrd@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (14, 'martinabecic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (721, 'matudic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (108, 'maxprestige@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (697, 'mazar.roza1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (446, 'mdjuricic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (444, 'mecco@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (71, 'meddo@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (494, 'melita@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (107, 'mercur.ag@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (567, 'michaela@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (328, 'migamvem@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (598, 'miholos@otenet.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (952, 'milekicliki@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (158, 'milica-milica@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (372, 'milicaristelic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (752, 'miljenko.perkic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (314, 'milos_bojic@outlook.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (574, 'milos_markicic@web.de');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (286, 'milos.cirkovic1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (840, 'milosavljevic_slavica@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (428, 'mina.svstefan@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (12, 'minabok@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (854, 'miodrag.antic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (586, 'mira123@otenet.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (949, 'mirisborova@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (304, 'mirjana.b.mrvaljevic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (696, 'mirjana.mikleus@ri.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (786, 'mirjana.sare@zd.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (150, 'mirjanatehnolog@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (610, 'mirko.bonacic@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (265, 'mirko086@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (189, 'mirkojancic1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (785, 'mirobudija@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (416, 'mirodurkovic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (818, 'miroslav.uzice87@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (355, 'misic.darco@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (433, 'mitar.papan@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (226, 'mitarkrivokapic44@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (550, 'mjesecevicd@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (68, 'mladenkarinja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (121, 'mlsboskovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (132, 'mmapartments1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (119, 'mmmamarkovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (98, 'mnholidays@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (290, 'montebay-villa@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (578, 'montebianco@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (238, 'montebianco@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (393, 'montenegro.apartments@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (89, 'montenegrohome@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (482, 'montenikola@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (78, 'monteroyale.budva@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (514, 'montesanbudva@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (386, 'more.radovici@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (230, 'moreig.hn@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (751, 'mperkic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (649, 'mpignoli@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (337, 'mrdaaleksa5@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (133, 'mrdak.nemanja33@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (45, 'msc.mne@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (20, 'mudresav@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (221, 'mvico1@myseneca.ca');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (422, 'mvucetic@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (820, 'nadaaco77@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (552, 'nadjajonica@aol.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (3, 'najsistem@sbb.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (86, 'nastasija95@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (635, 'natasa.hvizdak@gs.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (634, 'natasa@brana-tours.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (360, 'natasha-judo@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (49, 'naturavita09@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (828, 'nedastefanovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (104, 'nedeljko.injac@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (430, 'nedjor@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (220, 'nema.novi@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (208, 'nemanjavojvodic70@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (698, 'nenad.jaman@vip.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (179, 'nenadpress@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (886, 'nenazunic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (870, 'nesevicana@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (237, 'nevena@mira-mar.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (710, 'nfo@dalmatino-tours.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (867, 'nikazlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (324, 'nikmilor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (253, 'nikokaola@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (481, 'nikola_sutomore@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (848, 'nikola.djuric@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (259, 'nikolic.d.zeljko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (334, 'nikolicmaka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (333, 'niksamrsulja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (223, 'niksic-dzevad@t-online.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (130, 'nina.pribilovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (84, 'nlmtravelbranka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (66, 'nmilikic29@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (268, 'nobel@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (932, 'novakovdvor@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (976, 'novica544@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (451, 'nserventi@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (822, 'office@apartmanibohemia.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (904, 'office@apartmanipantelic.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (912, 'office@apartmaniresidence.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (92, 'office@hotellucic.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (75, 'office@marineroapartments.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (910, 'office@moteltara.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1038, 'office@vilaborova.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (987, 'office@vilapanorama.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (966, 'office@zlatiborskikatuni.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (516, 'oldmarinerkotor@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1012, 'omiljeni@mts.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (52, 'oregon@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (492, 'pamalabou@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (21, 'pansionkomovi@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (169, 'panto81@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (261, 'pavlejanko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (409, 'pejovic.nada@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (276, 'perobet@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (136, 'perovic.anita@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (613, 'petar.bakota@st.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (476, 'petar.j@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (562, 'petardss@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (432, 'petnik@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (279, 'petrovacapartmani@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (18, 'piljakr@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (74, 'pima@pima.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1018, 'pina@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (349, 'pipervgdj@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1035, 'planinskakuca@mail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (725, 'plitvicka-vila@vip.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (719, 'podgora@apartmanimilan.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (499, 'podostrog@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (317, 'pontusapartmani@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (594, 'porto_vistonis@xan.forthnet.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (57, 'postavljanjeoglasa@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (661, 'predrag.baretic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (921, 'prenocistekristina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (217, 'prima.montenegro1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (376, 'primetimail@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (607, 'primo022@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (207, 'privatnismjestajvelickovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (160, 'prlainovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (96, 'ptrradulovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (377, 'r.borny@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (653, 'rada.miljak@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (615, 'radovan.vezic@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (30, 'rafailovici11@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (16, 'rajkavojinovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (495, 'rajtours@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (289, 'rakocevic.apartments@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (398, 'raschko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (352, 'ratkovic@internetoglasi.org');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (26, 'rclub@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (374, 'rdblazo@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (543, 'rego-bis@rego-bis.pl');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (699, 'renata.ecim@st.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (906, 'reservations@hotelunionbelgrade.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (73, 'reserve@villabono.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (926, 'restorandincic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (669, 'ri-projekt@zg.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (994, 'ristanovicj@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (897, 'rjojic@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (658, 'robertmilling61@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (59, 'rodicjelena@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (761, 'rolandmikelic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (533, 'royal.azur@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1034, 'rujnodm@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (842, 'ruzicazlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1025, 'rzjzboj@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (113, 'sajohotel@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (79, 'sakiadrovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1000, 'sale_apollo@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (981, 'salemaric64@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (528, 'sales@avalaresort.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (415, 'sales@hotel-mediteran.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (460, 'sales@val-maslina.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (185, 'samo.cvetic94@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (151, 'sandra.catovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (135, 'sandraanic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (539, 'sandragregovicvucicevic@outlook.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (729, 'sanela.denjak@zg.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (672, 'sanja.dosen@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (510, 'sanja.macic83@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (81, 'sanja.penda@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (188, 'sanjaigalo@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (263, 'saras@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (576, 'sasha_hn@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (145, 'savcicbg@eunet.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (115, 'savodjilas@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (300, 'savovu@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (154, 'scruz@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (459, 'scungu@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (608, 'sebastijankraljic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (762, 'semir.covic@yahoo.co.uk');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (424, 'senadl@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (254, 'severin.mitic@etaz.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (535, 'shone090984@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (389, 'sidro.ulcinj@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (227, 'sijuksa@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (764, 'silvana.grgurevic@inet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (837, 'simkevlade@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (9, 'sinisaalempijevic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (418, 'sirenamarta@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (114, 'sjelena@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (387, 'skendoibroci@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1013, 'skischoolradan@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (711, 'sladjana_zd@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (993, 'sladjana.radomirovic@icloud.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (985, 'sladjanagajic84@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (123, 'sladjanainebojsamarijanovic9@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (233, 'slaki9@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (19, 'slavica.atanackovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (186, 'slavicaig@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (159, 'slavoljubdelic96@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (176, 'slavoljubdelicslavoljubdelic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (22, 'sljivancaninj@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (25, 'smestaj.todorovic.budva@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (855, 'smestajcolovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (330, 'smgolic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (508, 'smgs@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (88, 'snezanakov@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1021, 'snezanam@my-its.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (873, 'snezast@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (161, 'sobe.topla@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (733, 'sobezagreb@sobezagreb.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (216, 'sofia_vujinovic@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (845, 'soleveselinovic9@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (129, 'solka_the_best@mail.ru');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (408, 'somi.milosavljevic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (714, 'sonja.prpic@ri.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (35, 'spaso66@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (571, 'spinnaker@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (517, 'spiroradanovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (358, 'srbiva@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (692, 'Srecko.radun@xnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (579, 'srobert@cg.yu;srobert@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (271, 'srzenticapartments@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1023, 'stakicmz@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (641, 'stanko-st@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (604, 'stanko.sasic@zg.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1003, 'stankovicsrdjan70@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (525, 'stefan.jelusic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (37, 'stefannikcevic89@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (532, 'stelladicattaro@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (713, 'stiz@zg.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (164, 'stsneza@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (597, 'studiosvrionis@yahoo.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (157, 'Suncani.skalini.HN@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (866, 'sutrjelena@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (995, 'svetlana.davidovac@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (38, 'svetlanakra@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (633, 'tadic.mila@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (116, 'taffi_ks@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (643, 'tatjanaperanic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (602, 'termoinzenjering@po.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (503, 'termotehna@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (306, 'tesicmina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (647, 'tezina@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (914, 'the.belgrade.hills@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (183, 'tnatasa78@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (198, 'tomanovictamara@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (31, 'tomasevismilka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (457, 'tomicam1@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (178, 'tomicvd@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (614, 'tomluki1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (76, 'tomomarinkovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (821, 'tomonjici85@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (691, 'tonci.kresan@zd.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (690, 'tonci.kresan@zd.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (605, 'tonci.stanic@st.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (305, 'treshnja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (162, 'trojanovic.hercegnovi@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (204, 'ttea715@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (992, 'tucakov.nenad@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (806, 'tucovicdragana@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (560, 'turizam@sebastijan.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (170, 'ugrinovicbg@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (551, 'ulcini.apartments@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (298, 'umm@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (850, 'uros.interduopetrol@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (728, 'v.anusic@seznam.cz');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (118, 'varvar@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (101, 'vasiljevicmiroslav@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (312, 'vaskok@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (650, 'vbiondic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (174, 'vbv.beograd@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (741, 'vedranadobra@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (585, 'vekipipa@nadlanu.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (475, 'vekun@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (889, 'velanacm@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (556, 'vesna.alavanja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (171, 'vesna.vasic@fmk.edu.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (249, 'vicki74291@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (248, 'vicki74291@gmailc');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (195, 'vico_m@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (891, 'vidakovicnebojsa@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (795, 'vidichl@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (117, 'vidikovac@mail.ru');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (868, 'vidikovac02@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (988, 'vidikzova@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (450, 'viktorijamidzor@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (484, 'Vila_beba@live.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (327, 'vila_jelton@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (619, 'vila-dan@ciovo-trogir.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (753, 'vila.duga@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (918, 'vila.madams@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (923, 'vila.marija.palic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (425, 'vila.tati@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (804, 'vila.zmajevac@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1010, 'vilaanazlatibor@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (924, 'vilaborovasrebrnojezero@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (915, 'vilaboska@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1009, 'vilabozovic7@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (888, 'vilacortina@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (953, 'viladarik@ptt.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (479, 'viladijana@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (646, 'vilaja@net.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (916, 'vilajasmina@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (969, 'vilajelena@eunet.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (853, 'vilaknez@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (835, 'vilakosuta@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (487, 'vilakukoljac@cg.yu');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (486, 'vilakukoljac@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (852, 'vilaluna.zlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (951, 'vilamilena7patuljaka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (559, 'vilamilica@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (859, 'vilamirzlatibor@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (917, 'vilanikolas@open.telekom.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (315, 'vilaparaglajder@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1022, 'vilarujno@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (800, 'vilaskiradan@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (849, 'vilastikic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (922, 'vilatatjana@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (573, 'vilavujovic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (871, 'vilazlata@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (892, 'vilazlatiborskiandjeo@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1017, 'vilazora@eunet.rs');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (468, 'villa.ferri@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (718, 'villa.klaudia@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (756, 'villa.lina.brsecine@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (748, 'villadaly@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (743, 'villadaniela1@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (388, 'villaelena.ul@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (280, 'villanataliar@yahoo.com, info@skocidjevojka.net');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (368, 'villaroyal@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (689, 'vinkustura@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (34, 'vip@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (639, 'virna.cekada@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1031, 'vladan.d@getmail.no');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (856, 'vladan.kutlesic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (356, 'vlado.rajko@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (344, 'vladomilutinovic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (184, 'vlaovic.zeljkooo@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (167, 'vojnovic.miodrag@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (423, 'vuceticandjelka@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (876, 'vujovicmihailo@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (464, 'vukajf@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (106, 'vukasinlakic@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (90, 'vukcevic2012@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (370, 'vukmar1306@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (473, 'vukotic.buljarica@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (461, 'vusurovicmilica@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (596, 'welcome@g-hotels.gr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (303, 'wgrand@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (266, 'whisper21bg@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (172, 'windsurf_hn@hotmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (603, 'zaboric@email.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (946, 'zelenicardaci@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (792, 'zelimir.radovanovic@zd.t-com.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (791, 'zeliradovan@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (668, 'zeljka.koic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (674, 'zeljkasisara@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (612, 'zeljko.gligora@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (780, 'zeljko.simic@ka.htnet.hr');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (373, 'zeljkombn@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1016, 'zeljkostankovic78@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (53, 'zi12@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (957, 'zlatibor.vilapedja@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1020, 'zlatiborska.jezera.juzbasic@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (1037, 'zlatiborski.konak06@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (823, 'zlatiborskimir@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (447, 'zmura@t-com.me');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (894, 'zokamilovicue@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (13, 'zoran.nedeljkovic5@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (163, 'zoranbutulija@yahoo.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (720, 'zorok78@gmail.com');
INSERT INTO novosti (`novosti_id`, `email`) VALUES (309, 'zvizda@t-com.me');


#
# TABLE STRUCTURE FOR: objekat
#

DROP TABLE IF EXISTS objekat;

CREATE TABLE `objekat` (
  `objekat_id` int(11) NOT NULL AUTO_INCREMENT,
  `grad_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `ukupni_kapacitet` int(11) NOT NULL,
  `kordinata_x` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `kordinata_y` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `adresa` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `korisnik_id` int(11) NOT NULL,
  `kategorija_id` int(11) NOT NULL,
  `youtube_link` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kapara_id` int(11) NOT NULL,
  `tip_id` int(11) NOT NULL,
  `premium` int(11) NOT NULL,
  `prioritet` int(11) NOT NULL,
  `posecenost` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  PRIMARY KEY (`objekat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (1, 2, 'Sobe Igalo', 'Sobe Igalo je objekat za izdavanje soba u Igalu, nalazi se u blizini Titove Vile nedaleko od mora, pe&scaron;cana plaža je asocijacija na ovo lepo mesto. Izdajemo dve četvorokrevetne sobe, dve dvokrevetne sobe i jednu trokrevetnu, svaka soba ima zajedničko kupatilo sa jos jednom sobom. Obe četvorokrevetne i jedna dvokrevetna soba imaju balkon sa pogledom na more. Objekat takodje poseduje unutrasnju i spolja&scaron;nju kuhinju kompletno opremljenu. Deo za ručavanje je prostran i za&scaron;ticen od sunca lozom.Takodje imamo obezbedjen parking na zasebnom placu pored zgrade. Rezervacije i informacije mozete dobiti na telefon ili preko&nbsp;facebook&nbsp;stranice.', 15, '42.45297855251115', '18.504586815834045', 'http://bbuinac.users.sbb.rs/', 'Dr. Svetozara Zivoinovica', 9, 3, '', 7, 3, 1, 0, 1316, 1, 1461001690, 1478676910);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (6, 34, 'apartmani Zornija', 'apartmani Zornija smješteni su na samoj obali, na putu od Tivta prema Lepetanima,u mjestu zvanom Donja Lastva. Posjed od pet apartmana ima sopstvenu malu plažu opremljenu plažnim mobilijarom, što je sve na usluzi gostima apartmana. Zbog blizine plaže , apartmani su pogodni za porodičan odmor sa djecom. oOruženi zelenilom apartmani garantuju prijatnu domaćinsku atmosferu. Zbog svega toga, gosti koji jednom borave kod nas, uvijek nam se vraćaju.', 5, '42.451363652690226', '18.684973418712616', '', 'opatovo b.b. Tivat', 15, 3, '', 5, 3, 0, 10, 778, 1, 1461658672, 1478437745);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (8, 2, 'Apartman Pino Igalo', 'Izdajemo predivan apartman u Igalu, na setalistu, pored pjescane plaze, zatvorenog bazena i teniskih terena, preko puta banje Dr.Simo Milosevic. Nov, lijepo opremljen, sa odvojenom dnevnom i spavacom sobom, sa balkonom u krosnji starog bora i pogledom na ulaz u Bokokotorski zaliv. Na trecem - posljednjem spratu, tih, idealan za potpuni odmor, komforan za cetvoroclanu familiju.Apartman ima klimu,warles i kablovsku tv.', 1, '42.456647545121605', '18.510117530822754', 'www.apartmanpino-igalo.com', 'Sava Ilica 23a', 14, 4, '', 0, 4, 0, 10, 380, 1, 1461671167, 1478619875);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (11, 2, 'Apartman Dunja', 'Apartman Dunja nalazi se u samom centru Igala, na atraktivnoj lokaciji samo dva minuta od plaže kod Nautilus restorana. Apartman je smešten u prizemlju porodične kuće gde će vam biti na raspolaganju i nameštena terasa za odmor i uživanje.Odlična lokacija apartmana Dunja podrazumeva i markete, poštu, kafiće, restorane i šetalište kraj mora koji su udaljeni svega nekoliko desetina metara pa će vam praktično sve potrebno na letnjem odmoru biti na dohvat ruke. Uz sve ovo, za sve posetioce koji do Igala dolaze automobilom, u okviru apartmana Dunja obezbeđeno je i parking mesto.Apartman može ugodno da ugosti jednu porodicu ili četvoro prijatelja koji su odlučili da svoj odmor provedu upravo u centru Igala. Sastoji se od odvojene spavaće sobe sa velikim bračnim krevetom.Tu je u dnevnom boravku i dodatni krevet na razvlačenje koji se može prilagoditi kao ležaj za još dve osobe.U apartmanu Dunja postoji i potpuno opremljena kuhinja.TV je u dnevnom boravku sa velikim izborom kablovskih kanala, a takođe, u čitavom apartmanu dostupna vam je besplatna internet konekcija koju ćete moći da koristite za posao ili radi zabave. Apartman je klimatizovan tako da vam vreli letnji dani neće nimalo smetati, a pored toga izlazi i na terasu na kojoj se nalazi sto i dve stolice, a čiji će ambijent svakako ulepšati vaš boravak i načiniti vam prvu jutarnju kafu još savršenijom.', 4, '42.46068041844036', '18.518594652414322', '', 'Sarajevska 65', 20, 3, '', 4, 3, 0, 10, 395, 1, 1461673797, 1478692325);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (12, 36, 'Povoljno! Smestaj, od 15e za 4 osobe', 'DOBRODOSLI!!!!\n\nKrasici su malo mesto,nalaze se na poluostrvu Lustica,Boko Kotorski zaliv\nU ponudi imamo 4 apartmana sa po 4 lezaja,imamo i krevetac.Svi apartmani imaju sopstveni ulaz,kompletno opremljenu kuhinju,kupatilo,terasu sa pogledom na more,vodu 24h,internet.Apartmani su novi,cisti,izuzetno uredni.Nalaze se u mirnoj ulici,udaljeni od plaze 150m.Idealno za turiste kojima je potreban odmor u miru i tisini.\nNudimo vam gostoprimstvo,udobnost,miran boravak i ljubazne domacine.\nVise fotografija na : http://www.smestajmore.webs.com\nKontakt:0637304966, 0038232679926\nJUN I SEPTEMBAR-15-18e DNEVNO ZA APARTMAN(4 osobe)\nJUL I AVGUST-25-30e', 16, '42.409801289329344', '18.64650249481201', 'www.smestajmore.webs.com', 'Krasici', 13, 2, '', 6, 3, 0, 10, 497, 1, 1461738528, 1478437845);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (13, 2, 'Apartmani Borozan', 'Porodicna kuca Borozan se nalazi u Igalu najatraktivnijoj turistickoj destinaciji u Crnoj Gori,jos poznato kao centar zdravstvenog turizma.Kuca je smestena nadomak centra,a opet mirno ususkana u mediteranski ambijent okruzen cvecem i zelenilom,kao i prorodnom hladovinom kivija.Idealna lokacija kuce omogucuje vam da uzivate u burnom nocnom i dnevnom zivotu Igala,ali isto tako da provedete ptpuno miran i relaksirajuci odmor,bez buke u nocnim satima i sa cvrkutom ptica u jutarnjim satima. Kuca se nalazi u blizini velikog Roda marketa,tako da ce vam i nabavka svih neophodnih namirnica biti znatno laksa. Gostima su na raspolaganju tri apartmana od kojih su dva u prizemlju kuce potpuno renovirana i moderno opremljena. Treci apartman se nalazi na spratu kuce i u svom sklopu ima dve spavace sobe,kupatilo sa velikom kadom i ves masinom,kuhinju u staklenoj verandi sa svim neophodnim za kuvanje i rucavanje,veliki dnevni boravak sa trpezarijskim stolom i garniturom za sedenje.Iz dnevnog boravka kao i iz vece spavace sobe se izlazi na balkon. Takodje su gostima na raspolaganju veliko dvoriste sa bastenskom garniturom,rostiljem,kao i parking ispred kuce. Mir,privatnost i srdacnost domacina ce vas boravak uciniti prijatnim i ne zaboravnim. DOBRO DOSLI!!!!', 3, '42.46066458823833', '18.518268764019012', 'nemam', 'Sarajevska 67.', 22, 4, 'nemam', 6, 3, 0, 10, 592, 1, 1461788770, 1478437760);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (14, 2, 'APOLON', 'Apartmani Apolon nalaze se u Igalu na Petlji na 300 metara od mora i pruzaju vam sansu da uzivate u vasem odmoru sa stilom. Izaberite apartman ili sobu i uzivajte u vasem odmoru! Zasluzili ste to!', 15, '42.46202992844741', '18.511898517608643', 'www.apolon-igalo.com', 'petlja bb', 21, 3, '', 6, 3, 0, 10, 393, 1, 1461832408, 1478696883);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (15, 37, 'Apartmani Bogdanović', 'Apartmani Bogdanović nalaze se u Kumboru 4 km udaljeni od centra grada (Herceg Novi - stari grad). Kvalitet koji potvrđuju četri zvezdice, prijatna i opuštena atmosfera čine naše apartmane mestom gde uvek poželite da se vratite. Gostima su na raspolaganju trokrevetni, četvorokrevetni i petokrevetni apartmani na 200 i 70 metara udaljenosti od mora. Objekat je pokriven signalom za bezicni internet.\n\nOsnovni podaci:\n- Udaljenost od mora 200 i 70 metara\n- Parking prostor\n- TV i klima uređaj\n- Internet \n- Terasa sa pogledom na more', 4, '42.44007402349653', '18.589736223220825', 'https://www.facebook.com/apartmani.bogdnovic', 'Kumbor b.b.', 11, 4, '', 0, 3, 0, 10, 225, 1, 1461858512, 1478494755);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (16, 5, 'Apartman G10, Milmari kompleks', 'Apartman je kategorizovan sa 4 zvezdice i registrovan je za 4 osobe Nalazi se na trećem nivou novoizgrađenog objekta Milmari kompleksa, sa pogledom na jug i obronke planina Apartman je u jedan nivo ispod otvorenog i zatvorenog bazena, i dva nivoa ispod hotelskog restorana i recepcije Struktura apartmana o Hodnik o Dnevna soba sa trosedom na razvlačenje (Smart TV, DVD/BluRay) o Kompletno opremljena kuhinja sa trpezarijskim stolom Mikrotalasna, sudoma&scaron;ina, rerna, grejna ploča, kuvalo, toster, mikser&hellip; o Spavaća soba sa francuskim ležajem (TV, sef) o Kupatilo (fen) o Terasa (sto i četiri stolice) Besplatan Wi-Fi u celom kompleksu Kablovska televizija - Total TV (2 TV uređaja) Obezbeđeno parking mesto u nivou apartmana odmah do ulaza u objekat Obezbeđena besplatna skija&scaron;nica u hotelu kao i na stazi kod Konaka Maglić (popust na iznajmljivanje opreme) Milmari kompleks nudi sledeće dodatne usluge: o &Aacute; la Carte restoran o Pansionski restoran (&scaron;vedski sto, u zavisnosti od ponude hotela) o Bar o Wellness centar o Otvoreni i zatvoreni bazen o Skija&scaron;nica o Obezbedjen je prevoz vi&scaron;e puta dnevno od hotela do turističkog centra Kopaonika i ski staza (povratna karta 200 din.)', 4, '43.27526814311737', '20.75943946838379', 'www.kop-sun-ski.com', 'Milmari kompleks, Vikend naselje bb', 26, 4, '', 6, 2, 0, 14, 419, 1, 1461917204, 1478669222);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (17, 29, 'Rooms Banicevic', 'U lepom primorskom gradiću Risnu,u srcu Boko kotorskoga zaliva,izdajem sobe sa upotrebom kuhinje.Sve sobe su klimatizovane i imaju frižidere.Imamo sobe sa 2,3 i 4 ležaja.Takođe postoji mogućnost rezervacije sobe za samce po povoljnim cenama.\nNa raspolaganju imate kuhinju koja je zajednička za goste i komplet opremljena.\nKupatila su zajednička a na raspolaganju imate 2 kao i 2 vanjska tuša sa kabinama i toplom vodom.Gosti imaju obezbeđen besplatni parking i bežični internet.Kuća se nalazi na udaljenosti 300 - 400m od centra i mora.Gostima možemo obezbediti transport do aerodroma Tivat .', 16, '42.5151963692746', '18.699179738759995', 'banicevicsmjestaj.me', 'Gabela 21 Risan', 30, 1, 'Rooms Banicevic 1', 6, 3, 0, 10, 70, 1, 1466191547, 1478437734);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (18, 10, 'Budva apartmani', 'Apartmani se nalaze u novoj apartmanskoj zgradi na Jadranskom putu (glavna magistrala kroz Budvu), tačno preko puta Sajma i čuvene Slovenske plaže. Apartmani su udaljeni svega 500 metara od mora, a u blizini se nalaze kafići, restorani, pradavnice i još mnogo drugih sadržaja koji vam mogu zatrebati na letnjem odmoru (sve u krugu od 200 metara).\n\nStudio za 2 osobe\n\nStudiji su savršeni za parove. Sastoje se od udobnih kreveta, opremljene kuhinje, zasebnog kupatila i lepe terase sa pogledom na okolne pejzaže Budve.imamo dva studija u ponudi.\nKompletno su opremljeni svim novim savremenim sadržajima, a tu su TV sa kablovskim kanalima, klima uređaj, kao i besplatan bežični internet.\n\nApartman za 4 osobe\n\nOvi prostrani i lepo uređeni apartmani kojih ukupno imamo tri u ponudi, idealan su smeštaj za porodice ili grupu prijatelja koji žele da zajedno provedu letnji odomor.\n\nSvi apartmani imaju zasebnu spavaću sobu, zatim prostrani dnevni boravak, potpuno opremljenu kuhinju, zasebno kupatilo i lepu terasu sa pogledom na okolne pejzaže.\n\nTu su još i TV sa kablovskim kanalima, klima uređaj, kao i besplatan bežični internet.', 16, '42.288094860676836', '18.84176731109619', 'https://www.facebook.com/budvaapartmani/', 'Jadranski put bb', 31, 4, '', 0, 4, 0, 10, 285, 1, 1466191958, 1478692339);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (19, 38, 'Opatija, luksuzni apartmani 150 mod mora', 'Dragi gosti!\nNasa vila se nalazi  u mjestu Ičići pokraj Opatije. Kuca je na mirnoj lokaciji . Imamo luksuzni apartman sa pogledom na cijeli Kvarner,dva studio apartmana u prizemlju nase kuce sa posebnim ulazom i prekrasan bungalov . U nasem vrtu rastu prekrasne stoljetne palme ,ruzmarin, lavanda,bambus i mnoge druge biljke. Grill svim  nasim gostima je na raspolaganju. \nAci marina je udaljena 200m od kuce kao i plaza koja  je udaljena od kuce samo dvije minute pjeske. U blizini kuce su takoder dvije plaze za pse.  Za ljubitelje setnje tu je setnjica uz more ,poznati Lungo mare. Na 12 km dugackoj setnjici mozete uzivati u pogledu na more . Polazi kroz nekoliko mjesta, Opatiju, Icice, Iku,Lovran Volosko i Medveju.  \nNasi apartmani imaju 4 zvjezdice  i ukupno moze spavati 15 osoba u luksuznom suitu,2 studio apartmana i bungalovu. Internet je besplatan.\nKucne ljubimce  primamo uz doplatu.', 15, '45.313830798340405', '14.284511804580688', 'www.villa-jovic-croatia.weebly.com', 'Put za Veprinac 6, Icici Opatija', 32, 4, '', 4, 1, 0, 10, 279, 1, 1466192679, 1478437867);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (22, 10, 'Apartman vasilije', 'U blizini autobuske izdajem apartman sa odvojenom spavaćom sobom,10 minuta laganog hoda do plaze.\nApartman se sastoi odvojena spavaća soba,kuhinja,kupatilo,terasa,\nTv,wf,klima\nIspred kuće besplatan javni parking', 4, '100', '100', 'nema', 'Mimoze br 27', 34, 2, '', 6, 3, 0, 10, 58, 1, 1466200290, 1478437755);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (23, 2, 'Apartmani GaMa, s velikim dvoristem', 'Apartmani s odvojenim spavacim sobama, kapaciteta do 5 osoba. Ful opremljeni.\nVeliko dvoriste s djecijim igraliste, trampolinom, rostiljem, lezaljkama, i naravno besplatnim parkingom.\nPreko puta j Institut Igalo a s druge strane dvoriste izlazi na setaliste i plazu. \nMirno okruzenje.', 10, '42.4566450055462', '18.510552048683167', 'www.gama-igalo.com', 'Sava Ilica 23a, Igalo', 36, 4, '', 4, 4, 0, 10, 108, 1, 1466231581, 1478468090);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (24, 2, 'IGALO- SOBE, APARTMANI POVOLJNO !!!', 'Izdajem sobe i apartmane u Igalu(Herceg Novi-Crna Gora).Vrhunski smijestaj.Imaju kablovsku tv,parking,bezicni internet,kuhinja sa posudjem,kupatilo sa tus kabinom,klima,voda 24h,balkon sa pogledom na more,fen,pegla,gosti ispred kuce mogu koristit rostilj ,50m od kuce supermarket… Povoljna cijena sa popustom od septembra do juna\nImamo jednokrevetne,dvokrevetne,trokrevetne,cetvorokrevetne,petokrevetne sobe i apartmane\n\nNAS SAJT\nwww.apartmanimaric.com\nKONTAKT TEL.\nMOB.+38267207242\n+38231335300\nE-MAIL:moreig.hn@gmail.com', 14, '42.4620209584511', '18.511834144592285', 'http://www.apartmanimaric.com/', 'igalo,petlja', 37, 4, '', 2, 3, 0, 10, 115, 1, 1466232684, 1478503841);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (25, 2, 'Apartman, stan garsonjera Igalo', 'Iznajmljujem apartman u Igalu 26m2 sa balkonom, blizu instituta za fizikalnu medicinu, rehabilitaciju i reumatologiju \"Dr Simo Milosević\" (200m ). \nParking obezbjeđen, jedna soba sa dva lezaja, kuhinja (sa svime potrebnim), kupatilo, klimatizovano, Tv, internet Wifi.\nCijena zavisno od sezone, vremenskog perioda, i broja osoba za DJECU  DO 13 god. GRATIS.\nSve ostale informacije na:\n0038765/045-724 Djuro \n0038766150721 Aleksandar (VIBER, Whatsapp)', 5, '42.46210678235751', '18.508111238479614', 'www.olx.ba/djurodraksenic', 'Gomila', 38, 4, '', 4, 4, 0, 10, 126, 1, 1466239218, 1478437814);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (26, 4, 'Dvosoban stan', 'Izdajem turistima dvosoban stan(cijeli sprat kuće), dvije terase, parking, na 5 minuta od centra Herceg Novog, cijena 25 eura za 5 osoba kao i jednokrevetnu sobu sa upotrebom kupatila i kuhinje za 10 eura ženskoj osobi u okviru prvog sprata.\nKontakt na: mirjanatehnolog@gmail.com \n+38267224485', 5, '42.45357621321161', '18.539042472839355', 'mirjanatehnolog@gmail.com', 'Spasica i Masare BB', 42, 3, '', 4, 3, 0, 10, 327, 1, 1466597277, 1478621710);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (27, 27, '4-krevetne sobe u Baru, Dobre Vode', 'Izdajem dvije 4-krevetne sobe u Dobrim vodama u Baru na plazi Veliki pijesak. Kuca je na 5 minuta laganog hoda od plaze.\nSobe su dosta velike, klimatizovane,u sobi imaju 2 kreveta za po jednu osobu i jedan francuski lezaj za dvije osobe.\nKupatilo je zajednicko za 2 sobe, i ne postoji mogucnost da soba ima zasebno kupatilo.. postoji bojler i voda cijeli dan.\nZajednicka velika terasa za dvije sobe, kablovska televizija na terasi, upotreba kuhinje sa svim aparatima.\nCijena po dogovoru za noc po krevetu. moze 1 soba ili dvije po dogovoru. \nCijena varira od perioda kada se izdaje i broja nocenja. sto vise nocenja, manja je cijena.\nObezbijedjen parking pored kuce.\n\n\nkontakt i info na na +38267417143br>', 10, '42.03357996945908', '19.14616584777832', 'http://letovanje.crna.gora.me/item/2293', 'Ulica 83. DObre VOde, Bar', 43, 2, '', 6, 3, 0, 10, 191, 1, 1467805249, 1478619869);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (29, 2, 'Privatni smještaj Igalo', 'Privatni smještaj u Igalu na Pješčanoj plaži u blizini Titove vile, samo 20 metara od mora.', 8, '42.45261045400993', '18.50496768951416', 'http://privatnismjestajigalo.gdenamore.com', 'Dr Svetozara Živojinovića 17', 48, 3, '', 6, 3, 0, 10, 54, 1, 1469900842, 1478437785);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (30, 43, 'Apartmani Dalila Velika plaža Ulcinj', 'Ovaj objekat je udaljen 11 min hoda od plaže. Klimatizovani apartmani Dalila nalaze u centralnom delu Velike plaže. Objekat poseduje veliko dvorište sa voćnjakom. Gostima su na raspolaganju besplatan bežični internet, TV sa kablovskim kanalima i balkon ili terasa sa mrežom protiv komaraca.\n\nApartmani obuhvataju čajnu kuhinju. Bicikle možete iznajmiti u okviru objekta. Obezbeđen je besplatan parking.\n\nBarove sa živom muzikom, restorane i prodavnice pronaći ćete na samo 100 metara od apartmana Dalila. Centar istorijskog grada Ulcinja udaljen je 7 km. Obližnja Velika plaža duga je 12 km i nudi sadržaje za razne sportske aktivnosti, uključujući ronjenje i kajt-surfovanje.\n\nVlasnici apartmana Dalila mogu vam pomoći sa iznajmljivanjem automobila i organizovanjem izleta do Dubrovnika i odredišta u Crnoj Gori i Albaniji. Aerodromi u Tivtu i Podgorici nalaze se na manje od 90 km od objekta.\n\nOvaj objekat je takođe ocenjen kao najisplativiji u Ulconju! Gosti dobijaju više za svoj novac u poređenju sa drugim objektima u ovom gradu.\n\nGovorimo vaš jezik!\n\nApartments Dalila toplo dočekuje Booking.com goste od 21.', 20, '41.90368244037308', '19.305124282836914', 'http://dalila.me', 'Donji Štoj bb Maraševa ulica', 50, 3, 'https://www.youtube.com/watch?v=KHmTu8DDxUk', 8, 3, 0, 10, 17, 1, 1476214398, 1478437850);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (31, 33, 'Apartmani Kopitović', 'Apartmani se nalaze na udaljenosti od 270m od plaze,u mirnom kraju Petrovca.U ponudi imamo:\n1.Trokrevetni studio - prizemlje\n2.Dvokrevetni apartman-prizemlje\n3.Trokrevetni apartman-prizemlje\n4.Petokrevetni apartman prvi sprat\n5.Petokrevetni apartman drugi sprat\nApartmani na spratu su dvosobni,sa velikim kuhinjama i terasama .\nApartmani u prizemlju su novi,potpuno opremljeni, idealni za Vas odmor.\nPARKING PROSTOR!', 5, '42.20841089371713', '18.943058252334595', 'www.apartmani-kopitovic.info', 'III ulica 7', 54, 3, '', 6, 3, 0, 10, 9, 1, 1476280595, 1478619851);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (32, 5, 'Apartmani Vilaparaglajder', 'Naši Apartmani se nalaze u samom centru Kopaonika u Vili Paraglajder. U neposrednoj smo blizini šestoseda Karaman greben, druga kuća do staze, iznad kafea Dolly bell.  Naša adresa je: Pajino Preslo br.2, Kopaonik. Svaki apartman poseduje wireless konekciju i parking mesto. Za goste Vile Paraglajder obezbeđena je ski i bord oprema po najnižim cenama. Možete nas kontaktirati putem telefona: +38163237081, 38163309101,  +381600309101, kao i putem e-maila: vilaparaglajder@gmail.com.', 32, '43.28361007169932', '20.811796188354492', 'vilaparaglajder.com', 'Pajino preslo 2', 56, 3, '', 10, 3, 0, 10, 65, 1, 1476628631, 1478437790);


#
# TABLE STRUCTURE FOR: objekat_cene
#

DROP TABLE IF EXISTS objekat_cene;

CREATE TABLE `objekat_cene` (
  `objekat_cene_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `sezona_id` int(11) NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_cene_id`)
) ENGINE=InnoDB AUTO_INCREMENT=571 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (171, 1, 1, 1, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (172, 1, 1, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (173, 1, 1, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (174, 1, 1, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (175, 1, 1, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (186, 1, 2, 1, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (187, 1, 2, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (188, 1, 2, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (189, 1, 2, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (190, 1, 2, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (191, 1, 3, 1, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (192, 1, 3, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (193, 1, 3, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (194, 1, 3, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (195, 1, 3, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (196, 1, 4, 1, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (197, 1, 4, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (198, 1, 4, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (199, 1, 4, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (200, 1, 4, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (201, 1, 5, 1, '6', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (202, 1, 5, 2, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (203, 1, 5, 3, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (204, 1, 5, 4, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (205, 1, 5, 5, '5', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (251, 6, NULL, 1, '7', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (252, 6, NULL, 2, '7', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (253, 6, NULL, 3, '11', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (254, 6, NULL, 4, '7', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (255, 8, NULL, 2, '30', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (256, 8, NULL, 3, '50', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (257, 8, NULL, 4, '30', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (258, 8, NULL, 5, '25', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (294, 14, 16, 1, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (295, 14, 16, 2, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (296, 14, 16, 3, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (297, 14, 16, 4, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (298, 14, 16, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (299, 12, NULL, 1, '4', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (300, 12, NULL, 2, '4', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (301, 12, NULL, 3, '7', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (302, 12, NULL, 4, '4', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (303, 12, NULL, 5, '4', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (305, 15, NULL, 1, '10', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (376, 16, 18, 1, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (377, 16, 18, 2, '10', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (378, 16, 18, 3, '30', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (379, 16, 18, 4, '15', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (380, 16, 18, 5, '7', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (401, 18, NULL, 1, '10', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (402, 18, NULL, 2, '10', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (403, 18, NULL, 3, '25', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (404, 18, NULL, 4, '10', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (405, 18, NULL, 5, '10', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (411, 22, NULL, 1, '10', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (412, 22, NULL, 2, '10', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (413, 22, NULL, 3, '10', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (414, 22, NULL, 4, '10', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (415, 22, NULL, 5, '10', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (416, 23, NULL, 2, '50', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (417, 23, NULL, 3, '70', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (418, 23, NULL, 4, '50', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (419, 23, NULL, 5, '30', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (420, 25, NULL, 1, '5', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (421, 25, NULL, 2, '6', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (434, 26, NULL, 1, '5', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (440, 27, NULL, 1, '5', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (441, 27, NULL, 2, '5', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (442, 27, NULL, 3, '8', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (443, 27, NULL, 4, '5', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (444, 27, NULL, 5, '5', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (455, 16, NULL, 1, '7', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (456, 16, NULL, 2, '10', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (457, 16, NULL, 3, '25', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (458, 16, NULL, 4, '15', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (459, 16, NULL, 5, '7', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (470, 29, NULL, 1, '9', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (471, 29, NULL, 2, '9', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (472, 29, NULL, 3, '9', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (473, 29, NULL, 4, '9', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (474, 29, NULL, 5, '9', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (490, 1, NULL, 1, '6', 4);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (491, 1, NULL, 2, '7', 4);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (492, 1, NULL, 3, '8', 4);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (493, 1, NULL, 4, '7', 4);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (494, 1, NULL, 5, '5', 4);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (495, 19, NULL, 1, '7', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (501, 30, NULL, 1, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (502, 30, NULL, 2, '8', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (503, 30, NULL, 3, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (504, 30, NULL, 4, '8', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (505, 30, NULL, 5, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (506, 31, NULL, 1, '6', 5);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (507, 31, NULL, 2, '6', 5);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (508, 31, NULL, 3, '12', 5);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (509, 31, NULL, 4, '6', 5);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (510, 31, NULL, 5, '6', 5);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (526, 32, NULL, 1, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (527, 32, NULL, 2, '8', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (528, 32, NULL, 3, '18', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (529, 32, NULL, 4, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (530, 32, NULL, 5, '6', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (531, 32, 19, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (532, 32, 19, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (533, 32, 19, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (534, 32, 19, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (535, 32, 19, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (546, 32, 20, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (547, 32, 20, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (548, 32, 20, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (549, 32, 20, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (550, 32, 20, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (551, 32, 21, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (552, 32, 21, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (553, 32, 21, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (554, 32, 21, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (555, 32, 21, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (556, 32, 22, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (557, 32, 22, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (558, 32, 22, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (559, 32, 22, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (560, 32, 22, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (561, 32, 23, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (562, 32, 23, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (563, 32, 23, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (564, 32, 23, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (565, 32, 23, 5, '8', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (566, 32, 24, 1, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (567, 32, 24, 2, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (568, 32, 24, 3, '18', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (569, 32, 24, 4, '12', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (570, 32, 24, 5, '8', NULL);


#
# TABLE STRUCTURE FOR: objekat_detaljan_cenovnik
#

DROP TABLE IF EXISTS objekat_detaljan_cenovnik;

CREATE TABLE `objekat_detaljan_cenovnik` (
  `objekat_detaljan_cenovnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `od` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `do` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena_za` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`objekat_detaljan_cenovnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (13, 13, 10, '01/06/2016 12:00 AM', '01/07/2016 12:00 AM', '18', '18');
INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (14, 13, 10, '01/07/2016 12:00 AM', '01/09/2016 12:00 AM', '28', '28');
INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (15, 13, 10, '01/09/2016 12:00 AM', '01/10/2016 12:00 AM', '18', '18');
INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (31, 12, NULL, '01/06/2016 12:00 AM', '01/07/2016 12:00 AM', '18', '2');
INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (32, 12, NULL, '01/07/2016 12:00 AM', '01/09/2016 12:00 AM', '28', '2');
INSERT INTO objekat_detaljan_cenovnik (`objekat_detaljan_cenovnik_id`, `objekat_id`, `smestajna_jed_id`, `od`, `do`, `cena`, `cena_za`) VALUES (33, 12, NULL, '01/09/2016 12:00 AM', '01/10/2016 12:00 AM', '18', '2');


#
# TABLE STRUCTURE FOR: objekat_doba
#

DROP TABLE IF EXISTS objekat_doba;

CREATE TABLE `objekat_doba` (
  `objekat_doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `doba_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (66, 11, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (67, 11, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (68, 11, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (69, 11, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (80, 6, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (81, 6, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (82, 6, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (83, 6, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (84, 8, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (85, 8, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (86, 8, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (87, 8, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (101, 13, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (102, 13, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (103, 13, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (104, 13, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (105, 14, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (106, 14, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (107, 14, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (108, 14, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (109, 12, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (110, 12, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (111, 12, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (116, 15, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (117, 15, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (118, 15, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (119, 15, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (159, 17, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (160, 17, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (161, 17, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (162, 17, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (167, 18, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (168, 18, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (169, 18, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (170, 18, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (179, 20, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (180, 20, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (181, 20, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (182, 20, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (187, 22, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (188, 22, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (189, 22, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (190, 22, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (195, 23, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (196, 23, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (197, 23, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (198, 23, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (203, 19, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (204, 19, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (205, 19, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (206, 19, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (215, 24, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (216, 24, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (217, 24, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (218, 24, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (219, 25, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (220, 25, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (221, 25, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (222, 25, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (235, 26, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (237, 27, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (240, 16, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (241, 16, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (242, 16, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (243, 16, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (252, 29, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (253, 29, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (254, 29, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (255, 29, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (261, 1, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (264, 30, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (265, 30, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (278, 32, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (279, 32, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (280, 32, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (281, 32, 4);


#
# TABLE STRUCTURE FOR: objekat_iznajmljujese
#

DROP TABLE IF EXISTS objekat_iznajmljujese;

CREATE TABLE `objekat_iznajmljujese` (
  `objekat_iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `iznajmljujese_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (42, 11, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (48, 6, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (49, 8, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (54, 13, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (55, 14, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (56, 14, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (57, 12, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (58, 12, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (61, 15, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (62, 15, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (82, 17, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (85, 18, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (86, 18, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (93, 20, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (95, 22, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (97, 23, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (101, 19, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (102, 19, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (103, 19, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (112, 24, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (113, 24, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (114, 24, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (115, 24, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (116, 25, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (117, 25, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (118, 25, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (119, 25, 5);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (144, 26, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (145, 26, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (147, 27, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (150, 16, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (155, 29, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (156, 29, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (162, 1, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (166, 30, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (167, 30, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (168, 30, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (169, 31, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (176, 32, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (177, 32, 3);


#
# TABLE STRUCTURE FOR: objekat_karakteristike
#

DROP TABLE IF EXISTS objekat_karakteristike;

CREATE TABLE `objekat_karakteristike` (
  `objekat_karakteristika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `karakteristika_id` int(11) NOT NULL,
  `legenda_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_karakteristika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1461 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (489, 11, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (490, 11, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (491, 11, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (492, 11, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (493, 11, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (494, 11, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (495, 11, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (496, 11, NULL, 13, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (497, 11, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (498, 11, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (499, 11, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (540, 6, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (541, 6, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (542, 6, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (543, 6, NULL, 10, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (544, 6, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (545, 6, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (546, 6, NULL, 13, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (547, 6, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (548, 6, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (549, 6, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (550, 6, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (551, 6, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (552, 8, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (553, 8, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (554, 8, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (555, 8, NULL, 10, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (556, 8, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (557, 8, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (558, 8, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (559, 8, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (560, 8, NULL, 15, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (561, 8, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (562, 8, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (563, 8, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (641, 13, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (642, 13, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (643, 13, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (644, 13, NULL, 7, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (645, 13, NULL, 8, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (646, 13, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (647, 13, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (648, 13, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (649, 13, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (650, 13, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (651, 13, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (652, 13, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (653, 13, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (654, 13, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (655, 13, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (656, 14, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (657, 14, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (658, 14, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (659, 14, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (660, 14, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (661, 14, NULL, 12, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (662, 14, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (663, 14, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (664, 14, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (665, 14, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (666, 14, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (667, 14, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (684, 14, 16, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (685, 14, 16, 10, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (686, 14, 16, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (687, 14, 16, 13, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (688, 14, 16, 14, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (689, 14, 16, 15, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (690, 14, 16, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (691, 14, 16, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (692, 12, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (693, 12, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (694, 12, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (695, 12, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (696, 12, NULL, 9, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (697, 12, NULL, 10, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (698, 12, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (699, 12, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (700, 12, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (701, 12, NULL, 14, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (702, 12, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (703, 12, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (704, 12, NULL, 17, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (705, 12, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (720, 15, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (721, 15, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (722, 15, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (723, 15, NULL, 8, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (724, 15, NULL, 9, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (725, 15, NULL, 10, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (726, 15, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (727, 15, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (728, 15, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (729, 15, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (730, 15, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (731, 15, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (732, 15, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (733, 15, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (937, 17, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (938, 17, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (939, 17, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (940, 17, NULL, 11, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (941, 17, NULL, 12, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (942, 17, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (943, 17, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (944, 17, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (945, 17, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (946, 17, NULL, 17, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (947, 17, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (961, 18, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (962, 18, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (963, 18, NULL, 6, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (964, 18, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (965, 18, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (966, 18, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (967, 18, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (968, 18, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (969, 18, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (970, 18, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (971, 18, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (972, 18, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (973, 18, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1017, 22, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1018, 22, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1019, 22, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1020, 22, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1021, 22, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1022, 22, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1023, 22, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1024, 22, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1025, 22, NULL, 14, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1026, 22, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1027, 22, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1028, 22, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1029, 22, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1044, 23, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1045, 23, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1046, 23, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1047, 23, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1048, 23, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1049, 23, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1050, 23, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1051, 23, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1052, 23, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1053, 23, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1054, 23, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1055, 23, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1056, 23, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1057, 23, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1073, 19, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1074, 19, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1075, 19, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1076, 19, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1077, 19, NULL, 8, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1078, 19, NULL, 9, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1079, 19, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1080, 19, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1081, 19, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1082, 19, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1083, 19, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1084, 19, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1085, 19, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1086, 19, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1087, 19, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1088, 25, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1089, 25, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1090, 25, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1091, 25, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1092, 25, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1093, 25, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1094, 25, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1095, 25, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1096, 25, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1097, 25, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1098, 25, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1099, 25, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1174, 26, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1175, 26, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1176, 26, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1177, 26, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1178, 26, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1179, 26, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1180, 26, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1189, 27, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1190, 27, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1191, 27, NULL, 8, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1192, 27, NULL, 9, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1193, 27, NULL, 11, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1194, 27, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1195, 27, NULL, 14, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1196, 27, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1197, 27, NULL, 17, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1200, 16, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1201, 16, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1202, 16, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1203, 16, NULL, 4, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1204, 16, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1205, 16, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1206, 16, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1207, 16, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1208, 16, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1209, 16, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1210, 16, NULL, 14, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1211, 16, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1212, 16, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1213, 16, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1214, 16, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1243, 29, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1244, 29, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1245, 29, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1246, 29, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1247, 29, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1248, 29, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1249, 29, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1250, 29, NULL, 12, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1251, 29, NULL, 13, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1252, 29, NULL, 14, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1253, 29, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1254, 29, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1255, 29, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1256, 29, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1322, 1, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1323, 1, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1324, 1, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1325, 1, NULL, 9, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1326, 1, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1327, 1, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1328, 1, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1329, 1, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1330, 1, NULL, 14, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1331, 1, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1332, 1, NULL, 16, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1333, 1, NULL, 17, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1334, 1, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1340, 30, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1341, 30, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1342, 30, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1343, 30, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1344, 30, NULL, 7, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1345, 30, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1346, 30, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1347, 30, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1348, 30, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1349, 30, NULL, 13, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1350, 30, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1351, 30, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1352, 30, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1353, 30, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1354, 30, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1355, 31, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1356, 31, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1357, 31, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1358, 31, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1359, 31, NULL, 10, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1360, 31, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1361, 31, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1362, 31, NULL, 14, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1363, 31, NULL, 15, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1364, 31, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1365, 31, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1405, 32, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1406, 32, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1407, 32, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1408, 32, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1409, 32, NULL, 10, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1410, 32, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1411, 32, NULL, 12, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1412, 32, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1413, 32, NULL, 14, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1414, 32, NULL, 15, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1415, 32, NULL, 16, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1416, 32, NULL, 17, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1417, 32, NULL, 18, 3);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1418, 32, 19, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1419, 32, 19, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1420, 32, 19, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1421, 32, 19, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1422, 32, 19, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1435, 32, 20, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1436, 32, 20, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1437, 32, 20, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1438, 32, 20, 15, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1439, 32, 20, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1440, 32, 20, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1441, 32, 21, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1442, 32, 21, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1443, 32, 21, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1444, 32, 21, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1445, 32, 21, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1446, 32, 22, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1447, 32, 22, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1448, 32, 22, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1449, 32, 22, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1450, 32, 22, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1451, 32, 23, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1452, 32, 23, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1453, 32, 23, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1454, 32, 23, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1455, 32, 23, 17, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1456, 32, 24, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1457, 32, 24, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1458, 32, 24, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1459, 32, 24, 16, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (1460, 32, 24, 17, NULL);


#
# TABLE STRUCTURE FOR: objekat_nacinplacanja
#

DROP TABLE IF EXISTS objekat_nacinplacanja;

CREATE TABLE `objekat_nacinplacanja` (
  `objekat_nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `nacin_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (31, 6, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (32, 6, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (33, 8, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (36, 15, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (59, 18, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (62, 22, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (63, 22, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (64, 23, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (65, 25, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (66, 25, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (79, 26, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (82, 27, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (83, 27, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (86, 16, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (87, 16, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (95, 1, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (99, 30, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (100, 30, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (101, 30, 3);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (102, 31, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (103, 31, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (110, 32, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (111, 32, 2);


#
# TABLE STRUCTURE FOR: objekat_razdaljine
#

DROP TABLE IF EXISTS objekat_razdaljine;

CREATE TABLE `objekat_razdaljine` (
  `objekat_razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `razdaljine_id` int(11) NOT NULL,
  `vrednost` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`objekat_razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=564 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (223, 8, 1, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (224, 8, 2, '30m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (225, 8, 3, '15km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (226, 8, 4, '5m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (227, 8, 5, '1km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (228, 8, 6, '30m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (229, 8, 7, '300m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (230, 8, 8, '50m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (239, 12, 1, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (240, 12, 2, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (241, 12, 3, '11km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (242, 12, 4, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (243, 12, 5, '4km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (244, 12, 6, '180m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (245, 12, 8, '180m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (254, 15, 1, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (255, 15, 2, '250m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (256, 15, 3, '25km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (257, 15, 4, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (258, 15, 5, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (259, 15, 6, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (260, 15, 7, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (261, 15, 8, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (339, 18, 1, '500m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (340, 18, 2, '250m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (341, 18, 3, '15km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (342, 18, 4, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (343, 18, 5, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (344, 18, 6, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (345, 18, 7, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (346, 18, 8, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (347, 20, 1, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (348, 20, 2, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (349, 20, 3, '10');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (350, 20, 4, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (351, 20, 5, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (357, 22, 1, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (358, 22, 2, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (359, 22, 3, '10');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (360, 22, 4, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (361, 22, 5, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (362, 23, 1, '250');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (363, 23, 2, '15');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (364, 23, 3, '23');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (365, 23, 4, '2.5');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (366, 23, 5, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (367, 23, 6, '20');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (368, 23, 7, '250');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (369, 23, 8, '10');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (370, 19, 1, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (371, 19, 2, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (372, 19, 3, '30km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (373, 19, 4, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (374, 19, 5, '1500m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (375, 19, 6, '200m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (376, 19, 7, '500m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (377, 19, 8, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (378, 19, 10, '30km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (379, 25, 1, '450');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (380, 25, 2, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (381, 25, 4, '3 km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (418, 26, 1, '5');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (419, 26, 2, '6');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (420, 26, 4, '6');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (422, 27, 2, '250');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (423, 16, 1, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (424, 16, 4, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (425, 16, 5, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (426, 16, 10, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (427, 16, 15, '5km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (448, 29, 1, '1 km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (449, 29, 2, '20 m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (450, 29, 3, '25 km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (451, 29, 4, '3 km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (452, 29, 5, '2 km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (453, 29, 6, '50 m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (454, 29, 7, '100 m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (455, 29, 8, '100 m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (456, 29, 10, '-');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (457, 29, 15, '-');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (498, 1, 1, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (499, 1, 2, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (500, 1, 3, '3000');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (501, 1, 4, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (502, 1, 5, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (503, 1, 6, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (504, 1, 7, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (505, 1, 8, '70');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (514, 30, 1, '9km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (515, 30, 2, '1km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (516, 30, 3, '78km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (517, 30, 4, '7km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (518, 30, 5, '7km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (519, 30, 6, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (520, 30, 7, '150m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (521, 30, 8, '100m');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (522, 30, 10, '60km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (523, 30, 15, '60km');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (524, 31, 1, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (525, 31, 2, '250');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (526, 31, 3, '40000');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (527, 31, 4, '300');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (528, 31, 5, '80');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (529, 31, 6, '100');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (530, 31, 7, '400');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (531, 31, 8, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (556, 32, 1, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (557, 32, 4, '400');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (558, 32, 5, '500');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (559, 32, 6, '20');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (560, 32, 7, '50');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (561, 32, 8, '200');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (562, 32, 10, '20');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (563, 32, 15, '20');


#
# TABLE STRUCTURE FOR: objekat_slika
#

DROP TABLE IF EXISTS objekat_slika;

CREATE TABLE `objekat_slika` (
  `objekat_slika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putanja` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `datum` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `velicina` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `glavna` int(11) NOT NULL,
  PRIMARY KEY (`objekat_slika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (2, 1, '', '145864467.jpg', '1461003521', '130631', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (3, 1, '', '1788599673.jpg', '1461003521', '95016', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (4, 1, '', '1077733899.jpg', '1461003521', '89333', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (5, 1, '', '1358542188.jpg', '1461003521', '92461', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (6, 1, '', '1094829170.jpg', '1461003521', '88907', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (9, 1, '', '1510215838.jpg', '1461183836', '119099', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (10, 6, '-plaža-apartmana-Zornija-', '1761202058.JPG', '1461658987', '29791', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (11, 6, '-plaža-apartmana-Zornija-', '997734667.JPG', '1461658987', '16364', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (12, 6, '-plaža apartmana Zornija-', '1742675790.JPG', '1461658987', '18991', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (13, 6, '-plaža apartmana Zornija-', '1915262296.JPG', '1461658987', '8973', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (14, 6, '-plaža apartmana Zornija-', '428399721.JPG', '1461658987', '17640', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (15, 6, '-plaža apartmana Zornija-', '1822407978.JPG', '1461658987', '30812', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (16, 6, '-plaža apartmana Zornija-', '1706470723.JPG', '1461658987', '23786', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (17, 12, '', '1788894255.jpg', '1461738824', '79946', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (19, 12, '', '969547974.jpg', '1461738824', '91368', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (20, 12, '', '991218201.JPG', '1461738824', '197509', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (21, 12, '', '670194405.jpg', '1461738824', '153274', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (22, 12, '', '173068441.jpg', '1461738824', '93853', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (23, 12, '', '1113028743.jpg', '1461738824', '77013', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (24, 12, '', '1134342463.jpg', '1461738824', '380558', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (25, 12, '', '1548974592.jpg', '1461738824', '190251', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (26, 12, '', '284508794.jpg', '1461738825', '120378', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (27, 12, '', '1195805689.jpg', '1461738825', '54787', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (28, 12, '', '1337031417.jpg', '1461738825', '70377', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (29, 12, '', '127262703.jpg', '1461738825', '64509', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (30, 12, '', '1773606601.jpg', '1461738825', '56120', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (31, 12, '', '845460407.jpg', '1461738825', '120826', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (32, 12, '', '883155043.jpg', '1461738825', '62682', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (33, 12, '', '1272960634.jpg', '1461738825', '60115', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (34, 12, '', '732681973.jpg', '1461738825', '97633', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (37, 12, '', '201599012.jpg', '1461853630', '159997', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (38, 15, '', '1777061662.jpg', '1461858678', '81352', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (39, 15, '', '474009795.jpg', '1461858679', '66528', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (40, 15, '', '1185445446.jpg', '1461858679', '41823', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (41, 15, '', '298859482.jpg', '1461858679', '55966', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (42, 15, '', '1507039887.jpg', '1461858679', '40453', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (43, 15, '', '477369151.jpg', '1461858679', '46401', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (44, 15, '', '26670345.jpg', '1461858679', '74932', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (45, 15, '', '1747168464.jpg', '1461858679', '56180', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (46, 15, '', '1771951775.jpg', '1461858679', '65804', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (47, 15, '', '823423635.jpg', '1461858679', '47371', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (48, 15, '', '1439221425.jpg', '1461858679', '83405', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (49, 15, '', '607215585.jpg', '1461858679', '77561', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (73, 18, '', '262047406.jpg', '1466192368', '42567', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (74, 18, '', '1466482833.jpg', '1466192368', '47432', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (75, 18, '', '563230950.jpg', '1466192368', '46406', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (76, 18, '', '1942896866.jpg', '1466192368', '41140', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (77, 18, '', '17212652.jpg', '1466192368', '200250', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (78, 18, '', '342333910.jpg', '1466192369', '175438', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (79, 18, '', '653650694.jpg', '1466192369', '237279', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (80, 18, '', '1240347787.jpg', '1466192369', '185026', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (81, 18, '', '124401255.jpg', '1466192369', '293464', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (82, 18, '', '1992350288.jpg', '1466192369', '173015', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (83, 18, '', '1034612373.jpg', '1466192369', '148879', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (84, 18, '', '927188921.jpg', '1466192369', '175438', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (85, 18, '', '1881534175.jpg', '1466192369', '120617', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (86, 18, '', '340249733.jpg', '1466192369', '157665', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (87, 18, '', '1925437497.jpg', '1466192369', '49178', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (88, 18, '', '1486360981.jpg', '1466192369', '142243', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (89, 18, '', '1903059441.jpg', '1466192369', '136641', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (90, 18, '', '1093897673.jpg', '1466192369', '129826', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (91, 18, '', '657846889.jpg', '1466192370', '191613', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (92, 18, '', '2033637790.jpg', '1466192370', '167658', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (93, 19, 'Villa-Jovic', '619959874.jpg', '1466193927', '18072', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (94, 19, '', '1183253930.jpg', '1466193927', '1958342', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (95, 19, '', '1149456865.jpg', '1466193928', '81536', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (96, 19, '', '1386180107.JPG', '1466193928', '124449', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (97, 19, '', '235221448.jpg', '1466193928', '2162474', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (98, 19, '', '1852323565.jpg', '1466193928', '137434', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (99, 19, '', '515348166.jpg', '1466193928', '249091', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (100, 19, '', '1819036958.jpg', '1466193928', '236015', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (101, 19, '', '62173396.jpg', '1466193928', '222841', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (102, 19, '', '1235470202.JPG', '1466193928', '1898517', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (103, 19, '', '1024777899.JPG', '1466193928', '2462741', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (104, 19, '', '506650844.JPG', '1466193929', '1087296', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (105, 19, '', '349938219.JPG', '1466193929', '1117657', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (106, 19, '', '2039146241.jpg', '1466193929', '721359', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (107, 19, '', '606685524.jpg', '1466193929', '840825', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (108, 19, '', '670508860.jpg', '1466193930', '1048922', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (109, 19, '', '642647724.JPG', '1466193930', '63479', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (110, 19, '', '51699807.jpg', '1466193930', '981647', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (111, 19, '', '201983369.jpg', '1466193930', '753421', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (112, 19, '', '664730322.jpg', '1466193930', '184796', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (113, 23, '', '141638980.jpg', '1466232001', '447029', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (114, 23, '', '612611529.jpg', '1466232001', '193533', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (115, 23, '', '369094149.jpg', '1466232001', '150133', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (116, 23, '', '1782508641.jpg', '1466232001', '2651400', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (117, 23, '', '1265837548.JPG', '1466232001', '2638542', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (118, 23, '', '621537605.jpg', '1466232002', '2511711', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (119, 23, '', '1926180741.jpg', '1466232002', '323492', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (120, 23, '', '1637315784.jpg', '1466232002', '309872', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (121, 23, '', '1746392037.jpg', '1466232002', '166935', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (122, 23, '', '716557251.jpg', '1466232002', '79071', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (123, 23, '', '1036210775.jpg', '1466232002', '1596947', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (124, 23, '', '1735674977.jpg', '1466232002', '1539344', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (125, 23, '', '2138004342.jpg', '1466232002', '212010', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (126, 24, '', '1405546103.jpg', '1466232812', '43311', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (127, 24, '', '2082971532.jpg', '1466232812', '50446', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (128, 24, '', '696214302.jpg', '1466232812', '50446', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (129, 24, '', '1570305491.jpg', '1466232812', '97190', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (130, 24, '', '246789195.jpg', '1466232812', '60795', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (131, 24, '', '1974206037.jpg', '1466232890', '43311', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (132, 24, '', '8046714.jpg', '1466232890', '50446', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (133, 24, '', '1512301054.jpg', '1466232890', '98184', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (134, 24, '', '993626173.jpg', '1466232891', '60795', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (135, 24, '', '10368998.jpg', '1466232891', '97190', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (136, 26, 'Soba-u-stanu', '1030081893.jpg', '1466597388', '425113', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (137, 26, 'Kupatilo', '992574440.jpg', '1466597388', '1044700', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (138, 26, 'Kupatilo1', '1291363096.jpg', '1466597450', '1028829', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (139, 26, 'Soba1', '1025517293.jpg', '1466597518', '1298197', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (140, 26, 'Jednokrevetna-soba-prvom-spratu', '1421563812.jpg', '1466599149', '1058448', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (141, 26, 'Soba', '651342819.jpg', '1466599320', '425113', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (142, 26, 'Jednokrevetna-soba-prvom-spratu', '1309990158.jpg', '1466599321', '1058448', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (143, 26, 'Kupatilo1', '786710890.jpg', '1466599321', '1028829', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (144, 26, 'Kupatilo', '537177332.jpg', '1466599321', '1044700', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (145, 27, '', '579160730.jpg', '1467805398', '45319', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (146, 27, '', '1211757639.jpg', '1467805398', '135320', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (147, 27, '', '1594101448.jpg', '1467805398', '39165', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (148, 27, '', '635390411.jpg', '1467805398', '141957', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (149, 16, '', '436154814.jpg', '1470073685', '1230497', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (150, 16, '', '1651014561.png', '1470073686', '1076036', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (151, 16, '', '1271391898.png', '1470073687', '1484050', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (152, 16, '', '1475954512.jpg', '1470073687', '860727', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (153, 16, '', '1605819059.jpg', '1470073687', '1373018', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (154, 16, '', '1871007758.jpg', '1470073687', '1392311', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (155, 16, '', '41815414.jpg', '1470073687', '1205834', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (156, 16, '', '1394144323.jpg', '1470073688', '1363085', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (157, 16, '', '1921381354.jpg', '1470073688', '1047200', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (158, 16, '', '1425757659.jpg', '1470073688', '1164199', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (159, 29, '', '136716694.JPG', '1470211086', '1186820', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (160, 29, '', '88027665.jpg', '1470211087', '822072', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (161, 29, '', '787627355.jpg', '1472149243', '944260', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (164, 32, '', '606663070.jpg', '1476865779', '1195357', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (166, 32, '', '1868130541.jpg', '1476866530', '10684', 0);


#
# TABLE STRUCTURE FOR: privilegija
#

DROP TABLE IF EXISTS privilegija;

CREATE TABLE `privilegija` (
  `privilegija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `registracija` int(11) DEFAULT NULL,
  PRIMARY KEY (`privilegija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (1, 'Admin', 0);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (2, 'Premium korisnik', 1);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (3, 'Korisnik', 0);


#
# TABLE STRUCTURE FOR: privilegija_dozvole
#

DROP TABLE IF EXISTS privilegija_dozvole;

CREATE TABLE `privilegija_dozvole` (
  `privilegija_dozvole_id` int(11) NOT NULL AUTO_INCREMENT,
  `privilegija_id` int(11) NOT NULL,
  `dozvole_id` int(11) NOT NULL,
  `napomena` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`privilegija_dozvole_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (1, 2, 2, '2');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (2, 2, 1, '');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (3, 3, 2, '1');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (4, 3, 1, '');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (5, 2, 3, '10');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (6, 3, 3, '1');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (7, 2, 4, '');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (8, 3, 4, '');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (9, 3, 5, '1');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (10, 2, 5, '10');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (11, 3, 6, '2');
INSERT INTO privilegija_dozvole (`privilegija_dozvole_id`, `privilegija_id`, `dozvole_id`, `napomena`) VALUES (12, 2, 6, '6');


#
# TABLE STRUCTURE FOR: rating
#

DROP TABLE IF EXISTS rating;

CREATE TABLE `rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `ocena` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (1, 16, '5');
INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (2, 23, '5');
INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (3, 23, '3');
INSERT INTO rating (`rating_id`, `objekat_id`, `ocena`) VALUES (4, 26, '5');


#
# TABLE STRUCTURE FOR: razdaljine
#

DROP TABLE IF EXISTS razdaljine;

CREATE TABLE `razdaljine` (
  `razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (1, 'Od centra');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (2, 'Od plaze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (3, 'Od aerodroma');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (4, 'Od autobuske stanice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (5, 'Od ambulante');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (6, 'Od restorana');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (7, 'Od sportskih terena');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (8, 'Od prodavnice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (10, 'Od ski staze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (15, 'Od Žicare');


#
# TABLE STRUCTURE FOR: recnik
#

DROP TABLE IF EXISTS recnik;

CREATE TABLE `recnik` (
  `recnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr` text COLLATE utf8_unicode_ci NOT NULL,
  `en` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`recnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (2, 'Prijavi se', 'Log in');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (3, 'Početna', 'Home');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (4, 'Registruj se', 'Sign Up');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (9, 'Izaberite Drzavu', 'Choose Country');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (10, 'Registracija', 'Registration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (11, 'Zaboravili ste lozinku?', 'Frorgot your password?');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (12, 'Lozinka', 'Password');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (13, 'E-mail adresa', 'E-mail adress');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (14, 'Administracija Sajta', 'Website Administration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (15, 'Administracija Smestaja', 'Administration accommodations');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (17, 'Ime', 'Name');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (18, 'Prezime', 'Surname');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (19, 'ponovo', 'again');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (20, 'Opširnije', 'More');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (21, 'slika', 'pictures');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (22, 'Privatni', 'Private');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (23, 'Smestaj', 'Acommodation');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (24, 'Dobrodošli', 'Welcome');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (25, 'Pronadjite najbolje mesto za odmor', 'Find your best place for rest');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (26, 'Gde Hocete da idete?', 'Where you want to go?');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (27, 'Najposeceniji', 'Most visited');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (28, 'Smestaji', 'Accommodations');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (29, 'Smestajne jedinice', 'Accommodation units');


#
# TABLE STRUCTURE FOR: smestajnajed_slika
#

DROP TABLE IF EXISTS smestajnajed_slika;

CREATE TABLE `smestajnajed_slika` (
  `smestajnajed_slika_id` int(11) NOT NULL AUTO_INCREMENT,
  `smestajnajedinica_id` int(11) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putanja` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `datum` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `velicina` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `glavna` int(11) NOT NULL,
  PRIMARY KEY (`smestajnajed_slika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (1, 1, '', '823293870.jpg', '1461008490', '49023', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (2, 1, '', '36990935.jpg', '1461008618', '109184', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (3, 1, '', '304435511.jpg', '1461008618', '110475', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (4, 1, '', '512252220.jpg', '1461008619', '125184', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (5, 1, '', '1291542625.jpg', '1461008619', '109625', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (6, 2, '', '360664837.jpg', '1461143497', '67690', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (7, 2, '', '662737869.jpg', '1461143498', '106923', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (8, 2, '', '752732551.jpg', '1461143499', '57664', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (9, 2, '', '531102006.jpg', '1461143499', '59494', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (10, 3, '', '1794432779.jpg', '1461143568', '55595', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (11, 3, '', '116039233.jpg', '1461143568', '62548', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (12, 3, '', '1829751021.jpg', '1461143568', '69042', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (13, 3, '', '366105410.jpg', '1461143569', '59918', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (14, 3, '', '557457960.jpg', '1461143569', '78138', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (15, 4, '', '1891910610.jpg', '1461143634', '107060', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (16, 4, '', '429736253.jpg', '1461143634', '67066', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (17, 4, '', '181960230.jpg', '1461143634', '60260', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (18, 4, '', '1064331753.jpg', '1461143634', '72379', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (19, 4, '', '763518865.jpg', '1461143634', '64148', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (20, 5, '', '1104198178.jpg', '1461143665', '95422', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (21, 5, '', '602592191.jpg', '1461143666', '56358', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (22, 5, '', '2143699165.jpg', '1461143666', '58722', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (23, 5, '', '986187977.jpg', '1461143666', '55136', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (24, 5, '', '1342790940.jpg', '1461143666', '60254', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (38, 16, 'apolon', '1080720123.JPG', '1461841442', '2636621', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (39, 16, 'apartman', '2081308988.JPG', '1461841444', '41222', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (40, 16, 'apartman', '685791461.JPG', '1461841444', '3174554', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (41, 16, 'konoba', '1972567063.JPG', '1461841444', '105104', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (42, 16, 'terasa', '2092351347.JPG', '1461841444', '78665', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (43, 16, 'soba', '2107747432.JPG', '1461841444', '2745691', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (44, 18, '', '1553434254.JPG', '1461917786', '1125134', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (45, 18, '', '455094494.jpg', '1461917787', '1171855', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (46, 18, '', '1257290574.jpg', '1461917788', '525168', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (47, 18, '', '1359379442.jpg', '1461917788', '555944', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (48, 18, '', '766430538.jpg', '1461917788', '773420', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (49, 18, '', '1779672656.jpg', '1461917788', '717886', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (50, 18, '', '1855442230.JPG', '1461917788', '1111104', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (51, 18, '', '1885920907.JPG', '1461917788', '1419109', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (52, 18, '', '630994367.JPG', '1461917788', '1224655', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (53, 18, '', '1412382529.JPG', '1461917789', '1175289', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (54, 18, '', '629337536.JPG', '1461917789', '1134688', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (55, 18, '', '1122928040.JPG', '1461917789', '1067759', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (56, 18, '', '76606928.JPG', '1461917789', '1167554', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (57, 18, '', '178098329.JPG', '1461917789', '1009575', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (58, 18, '', '1900006663.JPG', '1461917790', '4724046', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (59, 18, '', '692342818.JPG', '1461917790', '1249880', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (60, 18, '', '935464830.JPG', '1461917790', '1267320', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (61, 18, '', '1437038409.JPG', '1461917790', '1260518', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (62, 18, '', '1726077324.JPG', '1461917791', '1401263', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (63, 18, '', '1979354349.JPG', '1461917791', '1336982', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (64, 18, '', '1646444687.jpg', '1461918076', '3866918', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (65, 18, '', '1349378050.png', '1461918076', '1076036', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (66, 18, '', '1968853802.png', '1461918077', '1234578', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (67, 18, '', '126789051.png', '1461918077', '1189159', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (68, 18, '', '313351617.png', '1461918077', '1306827', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (69, 18, '', '1357555299.png', '1461918077', '565298', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (70, 18, '', '1752309721.png', '1461918078', '1173387', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (71, 18, '', '1645774115.png', '1461918078', '1274611', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (72, 18, '', '1246858526.png', '1461918078', '1484050', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (73, 18, '', '115148100.png', '1461918078', '986709', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (74, 18, '', '335873584.png', '1461918079', '978446', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (75, 19, '', '390805172.jpg', '1476867128', '107111', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (76, 19, '', '2111684727.jpg', '1476867128', '104885', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (77, 19, '', '472527047.jpg', '1476867128', '74847', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (78, 19, '', '1019670923.jpg', '1476867128', '101626', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (79, 19, '', '1009654542.jpg', '1476867128', '93751', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (80, 19, '', '555688289.jpg', '1476867128', '79954', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (81, 19, '', '733361695.jpg', '1476867128', '98932', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (82, 20, '', '1671447172.jpg', '1476868514', '122705', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (83, 20, '', '1360821543.jpg', '1476868514', '105123', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (84, 20, '', '22583234.jpg', '1476870463', '97724', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (85, 20, '', '663950681.jpg', '1476870463', '100248', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (86, 20, '', '1055391463.jpg', '1476870463', '94435', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (87, 20, '', '1578388648.jpg', '1476870520', '115065', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (88, 20, '', '1515439431.jpg', '1476870521', '50730', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (89, 20, '', '169387211.jpg', '1476870521', '67868', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (90, 21, '', '814925385.jpg', '1476873245', '88215', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (91, 21, '', '1794579578.jpg', '1476873245', '84806', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (92, 21, '', '1502588428.jpg', '1476873246', '82606', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (93, 21, '', '1061413700.jpg', '1476873246', '79943', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (94, 21, '', '365843375.jpg', '1476873246', '90480', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (95, 21, '', '997221964.jpg', '1476873246', '79299', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (96, 22, '', '1985596019.jpg', '1476873490', '91747', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (97, 22, '', '2118423753.jpg', '1476873491', '88105', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (98, 22, '', '1682740646.jpg', '1476873491', '86358', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (99, 22, '', '145835006.jpg', '1476873491', '77211', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (100, 22, '', '1564821521.jpg', '1476873491', '82208', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (101, 23, '', '2054768541.jpg', '1476873801', '73126', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (102, 23, '', '861768081.jpg', '1476873801', '91712', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (103, 23, '', '615633316.jpg', '1476873801', '79328', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (104, 23, '', '629611880.jpg', '1476873801', '85222', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (105, 23, '', '2091847306.jpg', '1476873802', '84560', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (106, 23, '', '1125735228.jpg', '1476873802', '72626', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (107, 23, '', '1057325672.jpg', '1476873802', '83106', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (108, 24, '', '933299418.jpg', '1476874135', '103567', 1);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (109, 24, '', '1901052257.jpg', '1476874136', '96347', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (110, 24, '', '13991279.jpg', '1476874136', '108300', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (111, 24, '', '151821889.jpg', '1476874136', '100387', 0);
INSERT INTO smestajnajed_slika (`smestajnajed_slika_id`, `smestajnajedinica_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (112, 24, '', '1511635345.jpg', '1476874136', '98536', 0);


#
# TABLE STRUCTURE FOR: smestajnajedinica
#

DROP TABLE IF EXISTS smestajnajedinica;

CREATE TABLE `smestajnajedinica` (
  `smestajnajedinica_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `broj_mesta` int(11) NOT NULL,
  `vrsta_id` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`smestajnajedinica_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (1, 1, 'Plava četvorokrevetna', 'Plava četvorokrevetna soba nalazi se na prvom spratu sa pogledom na more velikim balkonom sa stolicama, televizorom, svaki ležaj je zaseban. Kupatilo deli sa jos jednom sobom, mogucnost kori&scaron;ćenja unutra&scaron;nje i spolja&scaron;nje kuhinje.', 4, 1, 1461003726, 1461008618, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (2, 1, 'Crvena trokrevetna', 'Crvena trokrevetna soba nalazi se na prvom spratu okrenuta severo-zapadno, zasebni ležajevi. Kupatilo deli sa jos jednom sobom, mogucnost kori&scaron;ćenja unutra&scaron;nje i spolja&scaron;nje kuhinje.', 3, 1, 1461003810, 1461143497, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (3, 1, 'Žuta dvokrevetna', 'Žuta dvokrevetna soba nalazi se na drugom spratu sa pogledom na more i balkonom velikim 20m&sup2;, bračni ležaj. Kupatilo deli sa jos jednom sobom, mogucnost kori&scaron;ćenja unutra&scaron;nje i spolja&scaron;nje kuhinje.', 2, 1, 1461003904, 1461143568, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (4, 1, 'Roze dvokrevetna', 'Roze dvokrevetna soba se nalazi u prizenmlju okrenuta je prema ulici, zasebni ležajevi. Kupatilo deli sa jos jednom sobom, mogucnost kori&scaron;ćenja unutra&scaron;nje i spolja&scaron;nje kuhinje.', 2, 1, 1461003993, 1461143634, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (5, 1, 'Narandzasta četvorokrevetna', 'Narandzasta četvorokrevetna soba nalazi se na drugom spratu sa pogledom na more i balkonom velikim 20m&sup2;, bracni ležaj i dva zasebna. Kupatilo deli sa jos jednom sobom, mogucnost kori&scaron;ćenja unutra&scaron;nje i spolja&scaron;nje kuhinje.', 4, 1, 1461004066, 1461143665, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (6, 13, 'Suzana apartman', 'Moderno uredjen apartman sa potpuno opremljenom kuhinjom(ugradna rerna,ravna ploca,masina za sudove i sve potrebno za rucavanje),trpezarijskim stolom sa barskim stolicama.Dnevni boravak koji moze imati fuunkciju spavace sobe,Kupatilo sa kadom,Spavaca soba sa bracnim krevetom,nocnicima i velikim ormarom,kao i komodom za TV.U ovu sobu po potrebi mozemo ubaciti pomocni krevet ili deciji krevetic.Ova soba ima svoje kupatilo sa ves masinim i tus kabinom.Apartman je klimatizovan i ima internet konekciju.', 5, 2, 1461792356, 1461792356, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (10, 13, 'Mali apartman', 'Apartman ima spavacu sobu sa bracnim krevetom gde postoji mogucnost da se stavi krevetic za bebu.Iz sobe se ulazi u veliko kupatilo sa tus kabinom i ves masinom.Kuhinja je opremljena za kuvanje i rucavanje.Dnevni boravak ima ugaonu garnituru koja kada se razvuce u funkciji je bracnog kreveta.Postoji mogucnost ubacivanja pomocnog kreveta.Apartman je klimatizovan i ima kablovsku konekciju.', 5, 2, 1461794052, 1461794052, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (16, 14, 'APOLON', '- dvokrevetne i trokrevetne \n- mogucnost dodavanja pomocnog kreveta \n- zasebno kupatilo \n- frizider \n- TV \n- klima \n- kupatilo sa tušem\n- terasa sa pogledom na more', 4, 1, 1461840528, 1461841442, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (17, 14, 'APOLON', '- dnevna soba sa trpezarijom \n- 1 spavaca soba\n- mogucnost dodavanje dodatnog kreveta\n- kuhinja sa svim pratecim elementima\n- kupatilo sa kadom\n- terasa sa pogledom na more\n- TV\n- Klima', 2, 2, 1461840580, 1461840580, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (18, 16, 'Apartman G10, Milmari kompleks', 'Apartman G10 ****\nApartman je kategorizovan sa 4 zvezdice i registrovan je za 4 osobe\nNalazi se na trećem nivou novoizgrađenog objekta Milmari kompleksa, sa pogledom na jug i obronke planina\nApartman je u jedan nivo ispod otvorenog i zatvorenog bazena, i dva nivoa ispod hotelskog restorana i recepcije\nStruktura apartmana\n    o    Hodnik\n    o    Dnevna soba sa trosedom na razvlačenje (Smart TV, DVD/BluRay)\n    o    Kompletno opremljena kuhinja sa trpezarijskim stolom\n                Mikrotalasna, sudomašina, rerna, grejna ploča, kuvalo, toster, mikser…\n    o    Spavaća soba sa francuskim ležajem (TV, sef)\n    o    Kupatilo (fen)\n    o    Terasa (sto i četiri stolice)\nBesplatan Wi-Fi u celom kompleksu\nKablovska televizija - Total TV (2 TV uređaja)\nObezbeđeno parking mesto u nivou apartmana odmah do ulaza u objekat\nObezbeđena besplatna skijašnica u hotelu kao i na stazi kod Konaka Maglić (popust na iznajmljivanje opreme)\nMilmari kompleks nudi sledeće dodatne usluge:\n    o    Á la Carte restoran\n    o    Pansionski restoran (švedski sto, u zavisnosti od ponude hotela)\n    o    Bar\n    o    Wellness centar\n    o    Otvoreni i zatvoreni bazen\n    o    Skijašnica\n    o    Obezbedjen je prevoz više puta dnevno od hotela do turističkog centra Kopaonika i ski staza (povratna karta 200 din.)\n\nwww.kop-sun-ski.com', 4, 2, 1461917786, 1461953632, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (19, 32, 'Apartman M-0', 'M-0 je apartman za 5-6 osoba, površine 35 metara kvadratnih. Nalazi se u prizemlju sa prednje strane kuće u nivou staze. Apartman se sastoji iz dnevne sobe (trosed koji se rasklapa u francuski ležaj i poseban francuski ležaj), spavaće sobe (francuski ležaj), kompletno opremljene kuhinje, kupatila i predsoblja-skijašnice. U apartmanu je dostupna wireless konekcija. Apartman poseduje zaseban ulaz i parking mesto.', 6, 2, 1476867128, 1476867128, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (20, 32, 'Apartman M-1', 'M-1 je apartman za 6-7 osoba, površine 55 metara kvadratnih. Nalazi se sa prednje strane kuće u nivou terase. Apartman je PRVE KATEGORIJE. Sastoji se od: predsoblja, komfornog kupatila sa kadom, odvojenog toaleta, dnevnog boravka sa kaminom (dva troseda koji se rasklapaju u francuski ležaj, kauč, TV, CD-DVD plejer), spavaće sobe sa francuskim ležajem, degažmana za garderobu (veliki frižider sa ledenom komorom), kompletno opremljene kuhinje sa šank barom i terase za sunčanje, površine 30 kvadratnih metara. U apartmanu je dostupna wireless konekcija. Uz apartman obezbeđeno je i parking mesto.', 7, 2, 1476868514, 1476870520, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (21, 32, 'Apartman M-2', 'M-2 je apartman za 3-4 osoba, površine 26 metara kvadratnih. Nalazi se na I spratu sa prednje strane kuće. Apartman je studijskog tipa – garsonjera u kojoj se nalaze francuski ležaj, trosed-kauč, mojca fotelja na razvlačenje, kompletno opremljena kuhinja i kupatilo. U apartmanu je dostupna wireless konekcija. Uz apartman obezbeđeno je i parking mesto.', 4, 2, 1476873245, 1476873245, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (22, 32, 'Apartman M-3', 'M-3 je apartman za 4-5 osoba, površine 28 metara kvadratnih. Nalazi se na visokom prizemlju sa gornje strane kuće. Apartman je studijskog tipa – garsonjera u kojoj se nalaze francuski ležaj, trosed-kauč, mojca fotelja na razvlačenje, kompletno opremljena kuhinja i kupatilo. U apartmanu je dostupna wireless konekcija. Uz apartman obezbeđeno je i parking mesto.', 5, 2, 1476873490, 1476873490, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (23, 32, 'Apartman M-4', 'M-4 je apartman za 4-6 osoba, površine 25 metara kvadratnih. Nalazi se na I spratu sa gornje strane kuće. Apartman se sastoji iz dnevne sobe (trosed koji se razvlači u francuski ležaj i francuski ležaj), kompletno opremljene kuhinje, galerije za spavanje (tri jogi dušeka) i kupatila. U apartmanu je dostupna wireless konekcija. Uz apartman obezbeđeno je i parking mesto.', 6, 2, 1476873801, 1476873801, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (24, 32, 'Apartman M-5', 'M-5 je apartman za 4-6 osoba, površine 25 metara kvadratnih. Nalazi se na II spratu sa prednje strane kuće. Apartman se sastoji iz dnevne sobe sa dva separea opremljena francuskim ležajima, kompletno opremljene kuhinje, galerije za spavanje (tri jogi dušeka) i kupatila. U apartmanu je dostupna wireless konekcija. Uz apartman je obezbeđeno i parking mesto.', 6, 2, 1476874135, 1476874135, 1);


#
# TABLE STRUCTURE FOR: tip
#

DROP TABLE IF EXISTS tip;

CREATE TABLE `tip` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO tip (`tip_id`, `naziv`) VALUES (1, 'Luksuzna Vila');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (2, 'Hotel');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (3, 'Kuća');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (4, 'Zgrada');


#
# TABLE STRUCTURE FOR: upit
#

DROP TABLE IF EXISTS upit;

CREATE TABLE `upit` (
  `upit_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `textupita` text COLLATE utf8_unicode_ci NOT NULL,
  `kontakt` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO upit (`upit_id`, `objekat_id`, `ime`, `prezime`, `email`, `textupita`, `kontakt`, `datum`, `stanje`) VALUES (1, 1, 'jovana', 'radic', 'jovana95ru@gmail.com', 'da li imate slobodnu sobu za mene i decka u terminu 22.7 do 2.8 i koja je cena?', '063255477', 19, 0);
INSERT INTO upit (`upit_id`, `objekat_id`, `ime`, `prezime`, `email`, `textupita`, `kontakt`, `datum`, `stanje`) VALUES (2, 29, 'Aleksandra ', 'Stanković', 'aleksandrastankovic94@gmail.com', '\nPoštovani, zanima me da li u periodu od 10-20.avgusta imate slobodnu dvokrevetnu sobu i koja bi bila cena noćenja po osobi? Srdačan pozdrav, Stanković Aleksandra', '0643572997', 1, 1);
INSERT INTO upit (`upit_id`, `objekat_id`, `ime`, `prezime`, `email`, `textupita`, `kontakt`, `datum`, `stanje`) VALUES (3, 29, 'Aleksandra ', 'Stanković', 'aleksandrastankovic94@gmail.com', '\nPoštovani, zanima me da li u periodu od 10-20.avgusta imate slobodnu dvokrevetnu sobu i koja bi bila cena noćenja po osobi? Srdačan pozdrav, Stanković Aleksandra', '0643572997', 1, 0);
INSERT INTO upit (`upit_id`, `objekat_id`, `ime`, `prezime`, `email`, `textupita`, `kontakt`, `datum`, `stanje`) VALUES (4, 29, 'Aleksandra ', 'Stanković', 'aleksandrastankovic94@gmail.com', '\nPoštovani, zanima me da li u periodu od 10-20.avgusta imate slobodnu dvokrevetnu sobu i koja bi bila cena noćenja po osobi? Srdačan pozdrav, Stanković Aleksandra', '0643572997', 1, 0);


#
# TABLE STRUCTURE FOR: upitdetaljno
#

DROP TABLE IF EXISTS upitdetaljno;

CREATE TABLE `upitdetaljno` (
  `upitdetaljno_id` int(11) NOT NULL AUTO_INCREMENT,
  `upit_id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upitdetaljno_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: usluge
#

DROP TABLE IF EXISTS usluge;

CREATE TABLE `usluge` (
  `usluge_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci,
  `cena` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`usluge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (1, 'Pozicija u mestu', '<p><span ><span ><strong ><em>dssssadsasagasga</em></strong></span></span></p>\r\n<h1><em><span><span><span><strong>&nbsp;</strong></span></span></span></em></h1>', '5');
INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (2, 'Premium paket', 's', '10');
INSERT INTO usluge (`usluge_id`, `naziv`, `opis`, `cena`) VALUES (3, 'Premium paket + pozicija u mestu', 'a', '15');


#
# TABLE STRUCTURE FOR: vrsta
#

DROP TABLE IF EXISTS vrsta;

CREATE TABLE `vrsta` (
  `vrsta_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`vrsta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (1, 'Soba');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (2, 'Apartman');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (3, 'Studio');


