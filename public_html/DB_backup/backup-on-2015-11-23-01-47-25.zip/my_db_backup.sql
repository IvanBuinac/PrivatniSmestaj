#
# TABLE STRUCTURE FOR: cenausezoni
#

DROP TABLE IF EXISTS cenausezoni;

CREATE TABLE `cenausezoni` (
  `cenausezoni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cenausezoni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (1, 'Minimalna cena po osobi');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (2, 'Predsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (3, 'U sezoni');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (4, 'Postsezona');
INSERT INTO cenausezoni (`cenausezoni_id`, `naziv`) VALUES (5, 'Van sezone');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3305b2e0c4b6d55c6ba8a64959d71917', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36', 1448239623, 'a:5:{s:3:\"ime\";s:4:\"Ivan\";s:5:\"email\";s:19:\"ivke-92@hotmail.com\";s:11:\"korisnik_id\";s:1:\"1\";s:14:\"privilegija_id\";s:1:\"1\";s:8:\"loggedin\";b:1;}');


#
# TABLE STRUCTURE FOR: doba
#

DROP TABLE IF EXISTS doba;

CREATE TABLE `doba` (
  `doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slika_obojena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slika_crno_bela` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (1, 'Zima', 'zima.png', 'zima_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (2, 'Leto', 'leto.png', 'leto_iskljuceno.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (3, 'Jesen', 'jesen.png', 'jesen_iskljucena.png');
INSERT INTO doba (`doba_id`, `naziv`, `slika_obojena`, `slika_crno_bela`) VALUES (4, 'Prolece', 'prolece.png', 'prolece_iskljuceno.png');


#
# TABLE STRUCTURE FOR: drzava
#

DROP TABLE IF EXISTS drzava;

CREATE TABLE `drzava` (
  `drzava_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`drzava_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (1, 'Srbija', 'srbija', '44.03232064275084', '20.8245849609375', 7, 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (2, 'Crna Gora', 'crna-gora', '42.819580715795915', '19.16839599609375', 8, 1);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (5, 'Hrvatska', 'hrvatska', '45.39844997630408', '15.99609375', 7, 0);
INSERT INTO drzava (`drzava_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`) VALUES (6, 'Grčka', 'grcka', '39.8465036024177', '22.247314453125', 8, 0);


#
# TABLE STRUCTURE FOR: grad
#

DROP TABLE IF EXISTS grad;

CREATE TABLE `grad` (
  `grad_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zoom` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `drzava_id` int(11) NOT NULL,
  PRIMARY KEY (`grad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (1, 'Beograd', 'beograd', '44.79085081250334', '20.457916259765625', 12, 1, 1);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (2, 'Igalo', 'igalo', '42.45541269782037', '18.506770133972168', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (4, 'Herceg Novi', 'herceg-novi', '42.45230964072516', '18.536295890808105', 15, 1, 2);
INSERT INTO grad (`grad_id`, `naziv`, `putanja`, `lat`, `long`, `zoom`, `status`, `drzava_id`) VALUES (5, 'Kopaonik', 'kopaonik', '43.28542202482845', '20.807676315307617', 15, 0, 1);


#
# TABLE STRUCTURE FOR: iznajmljujese
#

DROP TABLE IF EXISTS iznajmljujese;

CREATE TABLE `iznajmljujese` (
  `iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (1, 'sobe');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (2, 'studiji');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (3, 'apartmani');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (4, 'stanovi');
INSERT INTO iznajmljujese (`iznajmljujese_id`, `naziv`) VALUES (5, 'ceo objekat');


#
# TABLE STRUCTURE FOR: kalendar_popunjenosti
#

DROP TABLE IF EXISTS kalendar_popunjenosti;

CREATE TABLE `kalendar_popunjenosti` (
  `kalendar_popunjenosti_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `ime_prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `smestajna_jed_id` int(11) NOT NULL,
  PRIMARY KEY (`kalendar_popunjenosti_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (1, '2015-11-04', 'Pera peric', 1);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (2, '2015-11-05', 'Pera peric', 1);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (3, '2015-11-06', 'Pera peric', 1);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (4, '2015-11-11', 'hfdhfjgfjgf', 2);
INSERT INTO kalendar_popunjenosti (`kalendar_popunjenosti_id`, `datum`, `ime_prezime`, `smestajna_jed_id`) VALUES (5, '2015-11-04', 'dfhfdhdfhdf', 2);


#
# TABLE STRUCTURE FOR: kapara
#

DROP TABLE IF EXISTS kapara;

CREATE TABLE `kapara` (
  `kapara_id` int(11) NOT NULL AUTO_INCREMENT,
  `vrednost` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kapara_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (1, '5');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (2, '10');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (3, '15');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (4, '20');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (5, '25');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (6, '30');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (7, '35');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (8, '40');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (9, '45');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (10, '50');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (11, '55');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (12, '60');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (13, '65');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (14, '70');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (15, '75');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (16, '80');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (17, '85');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (18, '90');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (19, '95');
INSERT INTO kapara (`kapara_id`, `vrednost`) VALUES (20, '100');


#
# TABLE STRUCTURE FOR: karakteristike
#

DROP TABLE IF EXISTS karakteristike;

CREATE TABLE `karakteristike` (
  `karakteristike_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `chack` int(11) DEFAULT NULL,
  PRIMARY KEY (`karakteristike_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (1, 'Voda 24h', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (2, 'Pogodno za decu', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (3, 'Sef', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (4, 'Bazen', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (5, 'Obezbedjen parking', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (6, 'Garaža', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (7, 'Sobna usluga', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (8, 'Ljubimci dozvoljeni', 1);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (9, 'Kablovska', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (10, 'Pogled na more', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (11, 'Kupatilo', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (12, 'Kuhinja', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (13, 'Balkon', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (14, 'Klima', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (15, 'Velika terasa', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (16, 'Internet', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (17, 'Televizor', NULL);
INSERT INTO karakteristike (`karakteristike_id`, `naziv`, `chack`) VALUES (18, 'Telefon u sobi', NULL);


#
# TABLE STRUCTURE FOR: kategorija
#

DROP TABLE IF EXISTS kategorija;

CREATE TABLE `kategorija` (
  `kategorija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kategorija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (1, '1 Zvezdica');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (2, '2 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (3, '3 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (4, '4 Zvezdice');
INSERT INTO kategorija (`kategorija_id`, `naziv`) VALUES (5, '5 Zvezdica');


#
# TABLE STRUCTURE FOR: korisnik
#

DROP TABLE IF EXISTS korisnik;

CREATE TABLE `korisnik` (
  `korisnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `privilegija_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `drzava` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `grad` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `max_smestaja` int(11) DEFAULT NULL,
  `max_smestajnih_jed` int(11) DEFAULT NULL,
  `potvrda` int(11) NOT NULL,
  `rand` int(11) NOT NULL,
  PRIMARY KEY (`korisnik_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `drzava`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`) VALUES (1, 1, 'Ivan', 'Buinac', 'ivke-92@hotmail.com', 'dbbf9cbeb1b31bb85b44d760a970d42048450b316b96f6acabe57206870e0cc6ef554e3c031fbc5a9befed6fe77e53870b84f985ff480373bf66c4f9bdb1945c', 'Srbija', 'Beograd', 1, 0, 1, 0);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `drzava`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`) VALUES (5, 2, 'Ivan', 'Buinac', 'ivan.buinac.182.11@ict.edu.rs', 'dbbf9cbeb1b31bb85b44d760a970d42048450b316b96f6acabe57206870e0cc6ef554e3c031fbc5a9befed6fe77e53870b84f985ff480373bf66c4f9bdb1945c', 'Srbija', 'Beograd', 1, 1, 1, 12776);
INSERT INTO korisnik (`korisnik_id`, `privilegija_id`, `ime`, `prezime`, `email`, `password`, `drzava`, `grad`, `max_smestaja`, `max_smestajnih_jed`, `potvrda`, `rand`) VALUES (6, 3, 'nemanja', 'marjanovic', 'nemanja.marjanovic66@gmail.com', '54a8ba4cb9e074bbac6f5dd420d60e38e443de957d6a7ace465cf545d11295f7c248fd485d017a5f204b949be99c147de96bea487df7bebf891a7a244f507300', 'srbija', 'beograd', 1, 1, 1, 32258);


#
# TABLE STRUCTURE FOR: korisnik_kontakt
#

DROP TABLE IF EXISTS korisnik_kontakt;

CREATE TABLE `korisnik_kontakt` (
  `korisnik_kontakt_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnik_id` int(11) NOT NULL,
  `telefon` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`korisnik_kontakt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (1, 1, '2433-776');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (2, 7, '0113333333');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (3, 8, '0113333333');
INSERT INTO korisnik_kontakt (`korisnik_kontakt_id`, `korisnik_id`, `telefon`) VALUES (4, 7, '060/573-79-47');


#
# TABLE STRUCTURE FOR: legenda
#

DROP TABLE IF EXISTS legenda;

CREATE TABLE `legenda` (
  `legenda_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `slika` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`legenda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (1, 'Svaka soba, apartman', 'yes.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (2, 'Neke sobe, apartmani', 'maybe.png');
INSERT INTO legenda (`legenda_id`, `naziv`, `slika`) VALUES (3, 'Nema', 'no.png');


#
# TABLE STRUCTURE FOR: link
#

DROP TABLE IF EXISTS link;

CREATE TABLE `link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `meni_id` int(11) DEFAULT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tezina` int(11) DEFAULT NULL,
  `roditelj` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (1, 1, 'Početna', '', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (2, 2, 'Linkovi', 'admin/administracija_linkova', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (4, 3, 'Administracija Smestaja', '', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (5, 3, 'Administracija smestaja', 'korisnik/smestaji', 0, 4);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (6, 3, 'Upiti', 'korisnik/upiti', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (7, 3, 'Svi upiti', 'korisnik/upiti/index', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (8, 3, 'Obradjeni', 'korisnik/upiti/obradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (9, 3, 'Neobradjeni', 'korisnik/upiti/neobradjeni', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (10, 3, 'Poslati', 'korisnik/upiti/poslati', 1, 6);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (13, 3, 'Moj Profil', 'korisnik/moj_profil', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (14, 2, 'Levi meni', '', 2, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (15, 2, 'Meniji', 'admin/administracija_menija', 3, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (16, 2, 'Dashboard', 'admin/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (17, 2, 'Gradovi', 'admin/administracija_gradova', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (18, 2, 'Drzave', 'admin/administracija_drzava', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (19, 3, 'Dashboard', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (20, 2, 'Doba', 'admin/administracija_doba', 5, 14);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (23, 2, 'Korisnici', 'admin/administracija_korisnika', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (24, 2, 'Smestaji', 'admin/administracija_smestaja', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (25, 3, 'Administracija smestajnih jedinica', 'korisnik/smestajne_jedinice', 0, 4);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (26, 2, 'Administracija smestaja', 'korisnik/dashboard', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (27, 2, 'Smestajne jed', 'admin/smestajne_jedinice', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (28, 0, 'Kalendar popunjenosti', 'korisnik/kalendar_popunjenosti', 0, 0);
INSERT INTO link (`link_id`, `meni_id`, `naziv`, `putanja`, `tezina`, `roditelj`) VALUES (29, 0, 'backup_database', 'admin/dashboard/backup_database', 0, 0);


#
# TABLE STRUCTURE FOR: meni
#

DROP TABLE IF EXISTS meni;

CREATE TABLE `meni` (
  `meni_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`meni_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO meni (`meni_id`, `naziv`) VALUES (1, 'Gornji Meni');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (2, 'Administracija menija');
INSERT INTO meni (`meni_id`, `naziv`) VALUES (3, 'User_meni');


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO migrations (`version`) VALUES (7);


#
# TABLE STRUCTURE FOR: nacinplacanja
#

DROP TABLE IF EXISTS nacinplacanja;

CREATE TABLE `nacinplacanja` (
  `nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slikauboji` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `crnobela` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (1, 'Keš', 'kes.png', 'kes-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (2, 'Bankovni transfer', 'TBanks.png', 'TBanks-black.png');
INSERT INTO nacinplacanja (`nacinplacanja_id`, `naziv`, `slikauboji`, `crnobela`) VALUES (3, 'Kreditna kartica', 'kartica.png', 'kartica-black.png');


#
# TABLE STRUCTURE FOR: objekat
#

DROP TABLE IF EXISTS objekat;

CREATE TABLE `objekat` (
  `objekat_id` int(11) NOT NULL AUTO_INCREMENT,
  `grad_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `ukupni_kapacitet` int(11) NOT NULL,
  `kordinata_x` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `kordinata_y` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `adresa` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `korisnik_id` int(11) NOT NULL,
  `kategorija_id` int(11) NOT NULL,
  `youtube_link` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kapara_id` int(11) NOT NULL,
  `tip_id` int(11) NOT NULL,
  `premium` int(11) NOT NULL,
  `prioritet` int(11) NOT NULL,
  `posecenost` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  PRIMARY KEY (`objekat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (1, 2, 'sahasdadwsa', '<p>ahsasadsadsa</p>', 31, '42.453417893051565', '18.505353927612305', 'asgas', 'gsagsag', 1, 3, 'sagas', 7, 2, 1, 14, 138, 1, 1444759060, 1448215102);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (2, 2, 'gfdsfasfsa', '<p>sdasgsagsa</p>', 21, '42.45563433887255', '18.50471019744873', 'http://www.gdenamore.com/sr/crna-gora/igalo/apartmani-i-sobe-igalo-arnautovi%C4%87-o3213.html', 'gdfhfd', 1, 2, '', 6, 4, 1, 14, 170, 1, 1444759162, 1448215064);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (3, 2, 'fdsfdsfdsghds', '<p>gdsgsdgds</p>', 21, '42.4528479371616', '18.504323959350586', 'sdgsdg', 'dshfdhfd', 1, 4, 'sagasgasgsa', 5, 2, 1, 14, 207, 1, 1444773559, 1448239424);
INSERT INTO objekat (`objekat_id`, `grad_id`, `naziv`, `opis`, `ukupni_kapacitet`, `kordinata_x`, `kordinata_y`, `web`, `adresa`, `korisnik_id`, `kategorija_id`, `youtube_link`, `kapara_id`, `tip_id`, `premium`, `prioritet`, `posecenost`, `status`, `kreiran`, `modifikovan`) VALUES (4, 2, 'dsaghahashas', '<p>sadasdsa</p>', 21, '42.455349371661384', '18.505525588989258', 'sags', 'agsagsa', 1, 5, '', 14, 1, 1, 14, 139, 1, 1444773747, 1448215096);


#
# TABLE STRUCTURE FOR: objekat_cene
#

DROP TABLE IF EXISTS objekat_cene;

CREATE TABLE `objekat_cene` (
  `objekat_cene_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `sezona_id` int(11) NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_cene_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (121, 3, NULL, 1, '42', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (122, 3, NULL, 2, '47', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (123, 3, NULL, 3, '36', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (124, 3, NULL, 4, '63', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (125, 3, NULL, 5, '24', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (126, 1, NULL, 1, '32', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (127, 1, NULL, 2, '11', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (128, 1, NULL, 3, '22', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (129, 1, NULL, 4, '12', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (130, 1, NULL, 5, '15', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (131, 2, NULL, 1, '3', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (132, 2, NULL, 2, '2', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (133, 2, NULL, 3, '4', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (134, 2, NULL, 4, '2', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (135, 2, NULL, 5, '30', 2);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (141, 4, NULL, 1, '38', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (142, 4, NULL, 2, '15', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (143, 4, NULL, 3, '18', 1);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (144, 4, NULL, 4, '14', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (145, 4, NULL, 5, '36', 0);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (146, 3, 1, 1, '4', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (147, 3, 1, 2, '2', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (148, 3, 1, 3, '421', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (149, 3, 1, 4, '2', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (150, 3, 1, 5, '4', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (151, 3, 2, 1, '421', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (152, 3, 2, 2, '2', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (153, 3, 2, 3, '421', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (154, 3, 2, 4, '2', NULL);
INSERT INTO objekat_cene (`objekat_cene_id`, `objekat_id`, `smestajna_jed_id`, `sezona_id`, `cena`, `status`) VALUES (155, 3, 2, 5, '4', NULL);


#
# TABLE STRUCTURE FOR: objekat_detaljan_cenovnik
#

DROP TABLE IF EXISTS objekat_detaljan_cenovnik;

CREATE TABLE `objekat_detaljan_cenovnik` (
  `objekat_detaljan_cenovnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `od` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `do` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cena_za` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`objekat_detaljan_cenovnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: objekat_doba
#

DROP TABLE IF EXISTS objekat_doba;

CREATE TABLE `objekat_doba` (
  `objekat_doba_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `doba_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_doba_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (59, 3, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (60, 3, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (61, 3, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (62, 1, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (63, 1, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (64, 2, 2);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (65, 2, 3);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (66, 2, 4);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (69, 4, 1);
INSERT INTO objekat_doba (`objekat_doba_id`, `objekat_id`, `doba_id`) VALUES (70, 4, 4);


#
# TABLE STRUCTURE FOR: objekat_iznajmljujese
#

DROP TABLE IF EXISTS objekat_iznajmljujese;

CREATE TABLE `objekat_iznajmljujese` (
  `objekat_iznajmljujese_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `iznajmljujese_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_iznajmljujese_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (61, 3, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (62, 3, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (63, 1, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (64, 1, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (65, 2, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (66, 2, 2);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (67, 2, 3);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (68, 2, 4);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (71, 4, 1);
INSERT INTO objekat_iznajmljujese (`objekat_iznajmljujese_id`, `objekat_id`, `iznajmljujese_id`) VALUES (72, 4, 2);


#
# TABLE STRUCTURE FOR: objekat_karakteristike
#

DROP TABLE IF EXISTS objekat_karakteristike;

CREATE TABLE `objekat_karakteristike` (
  `objekat_karakteristika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `smestajna_jed_id` int(11) DEFAULT NULL,
  `karakteristika_id` int(11) NOT NULL,
  `legenda_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`objekat_karakteristika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (125, 3, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (126, 3, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (127, 3, NULL, 4, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (128, 3, NULL, 5, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (129, 3, NULL, 6, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (130, 1, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (131, 1, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (132, 1, NULL, 9, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (133, 1, NULL, 10, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (134, 1, NULL, 11, 1);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (135, 1, NULL, 12, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (136, 1, NULL, 13, 2);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (137, 2, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (138, 2, NULL, 2, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (139, 2, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (143, 4, NULL, 1, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (144, 4, NULL, 3, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (145, 4, NULL, 4, 0);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (146, 3, 1, 9, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (147, 3, 1, 10, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (148, 3, 1, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (149, 3, 1, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (150, 3, 1, 13, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (151, 3, 1, 14, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (152, 3, 2, 10, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (153, 3, 2, 11, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (154, 3, 2, 12, NULL);
INSERT INTO objekat_karakteristike (`objekat_karakteristika_id`, `objekat_id`, `smestajna_jed_id`, `karakteristika_id`, `legenda_id`) VALUES (155, 3, 2, 13, NULL);


#
# TABLE STRUCTURE FOR: objekat_nacinplacanja
#

DROP TABLE IF EXISTS objekat_nacinplacanja;

CREATE TABLE `objekat_nacinplacanja` (
  `objekat_nacinplacanja_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `nacin_id` int(11) NOT NULL,
  PRIMARY KEY (`objekat_nacinplacanja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (56, 3, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (57, 3, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (58, 3, 3);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (59, 1, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (60, 1, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (61, 2, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (62, 2, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (66, 4, 1);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (67, 4, 2);
INSERT INTO objekat_nacinplacanja (`objekat_nacinplacanja_id`, `objekat_id`, `nacin_id`) VALUES (68, 4, 3);


#
# TABLE STRUCTURE FOR: objekat_razdaljine
#

DROP TABLE IF EXISTS objekat_razdaljine;

CREATE TABLE `objekat_razdaljine` (
  `objekat_razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `razdaljine_id` int(11) NOT NULL,
  `vrednost` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`objekat_razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=266 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (226, 3, 1, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (227, 3, 2, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (228, 3, 3, '1');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (229, 3, 4, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (230, 3, 5, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (231, 3, 6, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (232, 3, 7, '1');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (233, 3, 8, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (234, 3, 10, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (235, 3, 15, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (236, 1, 1, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (237, 1, 2, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (238, 1, 3, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (239, 1, 4, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (240, 1, 5, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (241, 1, 6, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (242, 1, 7, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (243, 1, 8, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (244, 1, 10, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (245, 1, 15, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (246, 2, 1, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (247, 2, 2, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (248, 2, 3, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (249, 2, 4, '1');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (250, 2, 5, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (251, 2, 6, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (252, 2, 7, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (253, 2, 8, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (254, 2, 10, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (255, 2, 15, '1');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (261, 4, 1, '3');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (262, 4, 2, '2');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (263, 4, 3, '1');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (264, 4, 4, '4');
INSERT INTO objekat_razdaljine (`objekat_razdaljine_id`, `objekat_id`, `razdaljine_id`, `vrednost`) VALUES (265, 4, 5, '2');


#
# TABLE STRUCTURE FOR: objekat_slika
#

DROP TABLE IF EXISTS objekat_slika;

CREATE TABLE `objekat_slika` (
  `objekat_slika_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `putanja` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `datum` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `velicina` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `glavna` int(11) NOT NULL,
  PRIMARY KEY (`objekat_slika_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (2, 1, '', '12160.jpg', '1444759060', '845941', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (3, 1, '', '27065.jpg', '1444759061', '775702', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (5, 2, '', '20550.jpg', '1444759163', '561276', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (8, 3, '', '16528.jpg', '1444773559', '775702', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (10, 4, '', '8143.jpg', '1444773748', '780831', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (12, 3, '', '30898.jpg', '1444773926', '620888', 0);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (23, 3, '', '15015.jpg', '1445168065', '777835', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (24, 1, '', '29990.jpg', '1445168232', '780831', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (25, 2, '', '28414.jpg', '1445168256', '845941', 1);
INSERT INTO objekat_slika (`objekat_slika_id`, `objekat_id`, `naziv`, `putanja`, `datum`, `velicina`, `glavna`) VALUES (26, 4, '', '31525.jpg', '1445168271', '775702', 1);


#
# TABLE STRUCTURE FOR: privilegija
#

DROP TABLE IF EXISTS privilegija;

CREATE TABLE `privilegija` (
  `privilegija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `registracija` int(11) DEFAULT NULL,
  PRIMARY KEY (`privilegija_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (1, 'Admin', 0);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (2, 'Premium korisnik', 1);
INSERT INTO privilegija (`privilegija_id`, `naziv`, `registracija`) VALUES (3, 'Korisnik', 0);


#
# TABLE STRUCTURE FOR: razdaljine
#

DROP TABLE IF EXISTS razdaljine;

CREATE TABLE `razdaljine` (
  `razdaljine_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`razdaljine_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (1, 'Od centra');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (2, 'Od plaze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (3, 'Od aerodroma');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (4, 'Od autobuske stanice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (5, 'Od ambulante');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (6, 'Od restorana');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (7, 'Od sportskih terena');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (8, 'Od prodavnice');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (10, 'Od ski staze');
INSERT INTO razdaljine (`razdaljine_id`, `naziv`) VALUES (15, 'Od Žicare');


#
# TABLE STRUCTURE FOR: recnik
#

DROP TABLE IF EXISTS recnik;

CREATE TABLE `recnik` (
  `recnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr` text COLLATE utf8_unicode_ci NOT NULL,
  `en` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`recnik_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (2, 'Prijavi se', 'Log in');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (3, 'Početna', 'Home');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (4, 'Registruj se', 'Sign Up');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (9, 'Izaberite Drzavu', 'Choose Country');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (10, 'Registracija', 'Registration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (11, 'Zaboravili ste lozinku?', 'Frorgot your password?');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (12, 'Lozinka', 'Password');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (13, 'E-mail adresa', 'E-mail adress');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (14, 'Administracija Sajta', 'Website Administration');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (15, 'Administracija Smestaja', 'Administration accommodations');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (17, 'Ime', 'Name');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (18, 'Prezime', 'Surname');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (19, 'ponovo', 'again');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (20, 'Opširnije', 'More');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (21, 'slika', 'pictures');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (22, 'Privatni', 'Private');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (23, 'Smestaj', 'Acommodation');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (24, 'Dobrodošli', 'Welcome');
INSERT INTO recnik (`recnik_id`, `sr`, `en`) VALUES (25, 'Pronadjite najbolje mesto za odmor', 'Find best place for rest');


#
# TABLE STRUCTURE FOR: smestajnajedinica
#

DROP TABLE IF EXISTS smestajnajedinica;

CREATE TABLE `smestajnajedinica` (
  `smestajnajedinica_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `broj_mesta` int(11) NOT NULL,
  `vrsta_id` int(11) NOT NULL,
  `kreiran` int(11) NOT NULL,
  `modifikovan` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`smestajnajedinica_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (1, 3, 'asadf', '<p>hdfhfdfafsa</p>', 21, 1, 1448209190, 1448209190, 1);
INSERT INTO smestajnajedinica (`smestajnajedinica_id`, `objekat_id`, `naziv`, `opis`, `broj_mesta`, `vrsta_id`, `kreiran`, `modifikovan`, `status`) VALUES (2, 3, 'sagasgsa', '<p>hfdhfdhdfhdf</p>', 0, 1, 1448236492, 1448236492, 1);


#
# TABLE STRUCTURE FOR: tip
#

DROP TABLE IF EXISTS tip;

CREATE TABLE `tip` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO tip (`tip_id`, `naziv`) VALUES (1, 'Luksuzna Vila');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (2, 'Hotel');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (3, 'Kuća');
INSERT INTO tip (`tip_id`, `naziv`) VALUES (4, 'Zgrada');


#
# TABLE STRUCTURE FOR: upit
#

DROP TABLE IF EXISTS upit;

CREATE TABLE `upit` (
  `upit_id` int(11) NOT NULL AUTO_INCREMENT,
  `objekat_id` int(11) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `textupita` text COLLATE utf8_unicode_ci NOT NULL,
  `kontakt` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO upit (`upit_id`, `objekat_id`, `ime`, `prezime`, `email`, `textupita`, `kontakt`, `datum`, `stanje`) VALUES (1, 1, 'hsdhshsd', 'hsdhsdhsd', 'asgagsgas', 'fdjfdjfdjdf', '21521512', 25121521, 1);


#
# TABLE STRUCTURE FOR: upitdetaljno
#

DROP TABLE IF EXISTS upitdetaljno;

CREATE TABLE `upitdetaljno` (
  `upitdetaljno_id` int(11) NOT NULL AUTO_INCREMENT,
  `upit_id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `datum` int(11) NOT NULL,
  `stanje` int(11) NOT NULL,
  PRIMARY KEY (`upitdetaljno_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO upitdetaljno (`upitdetaljno_id`, `upit_id`, `email`, `text`, `datum`, `stanje`) VALUES (5, 1, 'ivke-92@hotmail.com', 'dsadsagasgasgasgas', 1431381508, 1);
INSERT INTO upitdetaljno (`upitdetaljno_id`, `upit_id`, `email`, `text`, `datum`, `stanje`) VALUES (6, 1, 'ivke-92@hotmail.com', 'sagasgasgsagasgas', 1431381512, 1);


#
# TABLE STRUCTURE FOR: vrsta
#

DROP TABLE IF EXISTS vrsta;

CREATE TABLE `vrsta` (
  `vrsta_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`vrsta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (1, 'Soba');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (2, 'Apartman');
INSERT INTO vrsta (`vrsta_id`, `naziv`) VALUES (3, 'Studio');


